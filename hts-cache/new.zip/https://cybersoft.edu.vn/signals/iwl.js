
<!DOCTYPE html>
<html lang="vi" prefix="og: http://ogp.me/ns#">
<head>
<meta charset="UTF-8"/>
<meta name="twitter:widgets:csp" content="on"/>
<link rel="profile" href="https://gmpg.org/xfn/11"/>
<link rel="pingback" href="https://cybersoft.edu.vn/xmlrpc.php"/>

<title>Không tìm thấy trang - CyberSoft Academy -Đào tạo Chuyên Gia Lập Trình</title>
<!-- Performance scores of this site is tuned by WP Performance Score Booster plugin v1.7.2 - http://wordpress.org/plugins/wp-performance-score-booster -->

<!-- This site is optimized with the Yoast SEO plugin v9.6 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="vi_VN" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Không tìm thấy trang - CyberSoft Academy -Đào tạo Chuyên Gia Lập Trình" />
<meta property="og:site_name" content="CyberSoft Academy -Đào tạo Chuyên Gia Lập Trình" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Không tìm thấy trang - CyberSoft Academy -Đào tạo Chuyên Gia Lập Trình" />
<!-- / Yoast SEO plugin. -->

<script type='application/javascript'>console.log('PixelYourSite Free version 9.4.7.1');</script>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Dòng thông tin CyberSoft Academy -Đào tạo Chuyên Gia Lập Trình &raquo;" href="https://cybersoft.edu.vn/feed/" />
<link rel="alternate" type="application/rss+xml" title="Dòng phản hồi CyberSoft Academy -Đào tạo Chuyên Gia Lập Trình &raquo;" href="https://cybersoft.edu.vn/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/cybersoft.edu.vn\/wp-includes\/js\/wp-emoji-release.min.js"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])?!1:!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55358,56760,9792,65039],[55358,56760,8203,9792,65039])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
		<style type="text/css">
			.epvc-eye {
				margin-right: 3px;
				width: 13px;
				display: inline-block;
				height: 13px;
				border: solid 1px #000;
				border-radius:  75% 15%;
				position: relative;
				transform: rotate(45deg);
			}
			.epvc-eye:before {
				content: '';
				display: block;
				position: absolute;
				width: 5px;
				height: 5px;
				border: solid 1px #000;
				border-radius: 50%;
				left: 3px;
				top: 3px;
			}
		</style>
	<link rel='stylesheet' id='kallyas-styles-css'  href='https://cybersoft.edu.vn/wp-content/themes/kallyas/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='page404-css-css'  href='https://cybersoft.edu.vn/wp-content/themes/kallyas/css/pages/page404.css' type='text/css' media='all' />
<link rel='stylesheet' id='zn_all_g_fonts-css'  href='//fonts.googleapis.com/css?family=Amatic+SC%3Aregular%2C700%7CMontserrat%3Aregular%2C700%7COpen+Sans%3A300%2Cregular%2C700%7CLato%7CPoppins%7CRoboto%7CRoboto+Condensed%7CRoboto+Mono%7CRoboto+Slab&#038;subset=vietnamese&#038;ver=5.0.21' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://cybersoft.edu.vn/wp-includes/css/dist/block-library/style.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://cybersoft.edu.vn/wp-content/plugins/revslider/public/assets/css/settings.css' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='wpfm-fontawesome-css'  href='https://cybersoft.edu.vn/wp-content/plugins/wp-floating-menu-pro/css/font-awesome/font-awesome.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='wpfm-frontend-genericons-css-css'  href='https://cybersoft.edu.vn/wp-content/plugins/wp-floating-menu-pro/css/genericons.css' type='text/css' media='all' />
<link rel='stylesheet' id='wpfm-frontend-vesper-icons-css-css'  href='https://cybersoft.edu.vn/wp-content/plugins/wp-floating-menu-pro/css/vesper-icons.css' type='text/css' media='all' />
<link rel='stylesheet' id='wpfm-frontend-css-css'  href='https://cybersoft.edu.vn/wp-content/plugins/wp-floating-menu-pro/css/front-end.css' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='https://cybersoft.edu.vn/wp-includes/css/dashicons.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='hpr-style-css'  href='https://cybersoft.edu.vn/wp-content/plugins/hotline-phone-ring/assets/css/style-1.css' type='text/css' media='all' />
<link rel='stylesheet' id='wppopups-base-css'  href='https://cybersoft.edu.vn/wp-content/plugins/wp-popups-lite/src/assets/css/wppopups-base.css' type='text/css' media='all' />
<link rel='stylesheet' id='hg-mailchimp-styles-css'  href='https://cybersoft.edu.vn/wp-content/themes/kallyas/framework/hogash-mailchimp/assets/css/hg-mailchimp.css' type='text/css' media='all' />
<link rel='stylesheet' id='th-bootstrap-styles-css'  href='https://cybersoft.edu.vn/wp-content/themes/kallyas/css/bootstrap.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='th-theme-template-styles-css'  href='https://cybersoft.edu.vn/wp-content/themes/kallyas/css/template.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='dhvc-form-font-awesome-css'  href='https://cybersoft.edu.vn/wp-content/plugins/dhvc-form/assets/fonts/font-awesome/css/font-awesome.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='dhvc-form-css'  href='https://cybersoft.edu.vn/wp-content/plugins/dhvc-form/assets/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='zion-frontend-css'  href='https://cybersoft.edu.vn/wp-content/themes/kallyas/framework/zion-builder/assets/css/znb_frontend.css' type='text/css' media='all' />
<link rel='stylesheet' id='kallyas-child-css'  href='https://cybersoft.edu.vn/wp-content/themes/kallyas-child/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='animate.css-css'  href='https://cybersoft.edu.vn/wp-content/themes/kallyas/css/vendors/animate.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='kallyas-addon-nav-overlay-css-css'  href='https://cybersoft.edu.vn/wp-content/plugins/kallyas-addon-nav-overlay/assets/styles.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='th-theme-print-stylesheet-css'  href='https://cybersoft.edu.vn/wp-content/themes/kallyas/css/print.css' type='text/css' media='print' />
<link rel='stylesheet' id='th-theme-options-styles-css'  href='//cybersoft.edu.vn/wp-content/uploads/zn_dynamic.css' type='text/css' media='all' />
<link rel='stylesheet' id='wpfm-google-fonts-css'  href='//fonts.googleapis.com/css?family=Roboto%3A100italic%2C100%2C300italic%2C300%2C400italic%2C400%2C500italic%2C500%2C700italic%2C700%2C900italic%2C900&#038;ver=5.0.21' type='text/css' media='all' />
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-includes/js/jquery/jquery.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-includes/js/jquery/jquery-migrate.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var sfpp_script_vars = {"language":"vi","appId":"297186066963865"};
/* ]]> */
</script>
<script type='text/javascript' async="async" src='https://cybersoft.edu.vn/wp-content/plugins/simple-facebook-twitter-widget/js/simple-facebook-page-root.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/sticky-menu-or-anything-on-scroll/assets/js/jq-sticky-anything.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/wp-floating-menu-pro/js/frontend.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/pixelyoursite/dist/scripts/jquery.bind-first-0.2.3.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/pixelyoursite/dist/scripts/js.cookie-2.1.3.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pysOptions = {"staticEvents":{"facebook":{"init_event":[{"delay":0,"type":"static","name":"PageView","pixelIds":["498491967837119"],"eventID":"9c96886e-e733-419e-a64c-e913fb8c7e6c","params":{"post_type":false,"plugin":"PixelYourSite","user_role":"guest","event_url":"cybersoft.edu.vn\/signals\/iwl.js"},"e_id":"init_event","ids":[],"hasTimeWindow":false,"timeWindow":0,"woo_order":"","edd_order":""}]}},"dynamicEvents":[],"triggerEvents":[],"triggerEventTypes":[],"facebook":{"pixelIds":["498491967837119"],"advancedMatching":{"external_id":"effecadcfeefcbbfaacecedffbf"},"advancedMatchingEnabled":true,"removeMetadata":false,"contentParams":[],"commentEventEnabled":true,"wooVariableAsSimple":false,"downloadEnabled":true,"formEventEnabled":true,"serverApiEnabled":true,"wooCRSendFromServer":false,"send_external_id":null},"debug":"","siteUrl":"https:\/\/cybersoft.edu.vn","ajaxUrl":"https:\/\/cybersoft.edu.vn\/wp-admin\/admin-ajax.php","ajax_event":"23e3682513","enable_remove_download_url_param":"1","cookie_duration":"7","last_visit_duration":"60","enable_success_send_form":"","ajaxForServerEvent":"1","send_external_id":"1","external_id_expire":"180","gdpr":{"ajax_enabled":false,"all_disabled_by_api":false,"facebook_disabled_by_api":false,"analytics_disabled_by_api":false,"google_ads_disabled_by_api":false,"pinterest_disabled_by_api":false,"bing_disabled_by_api":false,"externalID_disabled_by_api":false,"facebook_prior_consent_enabled":true,"analytics_prior_consent_enabled":true,"google_ads_prior_consent_enabled":null,"pinterest_prior_consent_enabled":true,"bing_prior_consent_enabled":true,"cookiebot_integration_enabled":false,"cookiebot_facebook_consent_category":"marketing","cookiebot_analytics_consent_category":"statistics","cookiebot_tiktok_consent_category":"marketing","cookiebot_google_ads_consent_category":null,"cookiebot_pinterest_consent_category":"marketing","cookiebot_bing_consent_category":"marketing","consent_magic_integration_enabled":false,"real_cookie_banner_integration_enabled":false,"cookie_notice_integration_enabled":false,"cookie_law_info_integration_enabled":false},"cookie":{"disabled_all_cookie":false,"disabled_advanced_form_data_cookie":false,"disabled_landing_page_cookie":false,"disabled_first_visit_cookie":false,"disabled_trafficsource_cookie":false,"disabled_utmTerms_cookie":false,"disabled_utmId_cookie":false},"woo":{"enabled":false},"edd":{"enabled":false}};
/* ]]> */
</script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/pixelyoursite/dist/scripts/public.js'></script>
<link rel='https://api.w.org/' href='https://cybersoft.edu.vn/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://cybersoft.edu.vn/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://cybersoft.edu.vn/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.0.21" />
<meta property="fb:app_id" content="825304329017984"/><script src="https://cybersoft.edu.vn/wp-content/themes/kallyas/js/jquery.malihu.PageScroll2id.min.js"></script>

<!-- Global site tag (gtag.js) - Google Ads: 964782458 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-964782458"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-964782458');
</script>

<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/course-anim-22-11.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/leftmenu_v6_12.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyberbutton_2020_ver1_4.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyberplay5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyberheader_ver14.css?v=1.0.6">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cybercriculum_ver6.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/decuong_uu_viet_89_ver1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_banner_v02.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/glass_box_chu_de_v6.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_video_ver5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_home_career_ver05.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_bcamp_ver19.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_course_info_ver8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_roadmap_ver35_1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_header_ver5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_course_illu_ver8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_sidebar_ver000.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_footer_v01.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style__navbar.css?v=2.2.9">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_menucircle_v08.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style_footer--location_v01.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style__global_v04.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style__capstone_v5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style__final--project_v2_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/style__final--project--style1_v5_7.css">


<!--New CSS-->
<link rel="stylesheet" href="https://cybersoft.edu.vn/wp-content/cybercss/cybertheme_color_v02.css">
<link rel="stylesheet" href="https://cybersoft.edu.vn/wp-content/cybercss/cybertheme_text_v02.css">
<link rel="stylesheet" href="https://cybersoft.edu.vn/wp-content/cybercss/cybertheme_spacing_v02.css">
<link rel="stylesheet" href="https://cybersoft.edu.vn/wp-content/cybercss/cybertheme_listgroup_v06_8.css">


<link rel="stylesheet" href="https://cybersoft.edu.vn/wp-content/cybercss/line-awesome_v1.css">
<link href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_aos.css" rel="stylesheet">
<link href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_fancyBox.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_imgbox.css?v=2.16.2">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_details_v2_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_project_capstone_v5_7.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_courseInfo_v5_3.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_different_v18_22.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_courseOutput_v2_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_learning_system_v7_1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_scrollingLogo_v1_8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_targetCource.css?v=7.1.6">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_slick_v1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_slick_theme_v1_1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_roadmap_index_v1_3.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_custome_slick_v1_6.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_roadmap_v7_5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_cards_stack_v1_7.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_training_methods.css?v=1.0.5">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_subBanner_v1_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_bang_cap_viec_lam_v4_5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_introduce_course_v20_9.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_resignter_v2_8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_custom_dropdown_v2_6.css">

<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_teacher_trainingMethod_v1_6.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyberHeaderMenu_v1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_custom_formOpening_v2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyberfaq_v1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_discount_v2_4.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_course_information_v3.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_custom_grid_gallery_v1_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_shape_information_v1_7.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/customAnchor_v1_5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_custom_gridVideo_v1_9_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_banner.css?v=5.4.2">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_feedback.css?v=1.5.2">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_support_learning_v2_5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_custom_phanDau_v6_1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyberCardBox.css?v=1.9.3">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_logo_pj_final_v3_5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/feedback_reviews_v4_5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_system_study_v2_6.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/blog_customItem_v6_1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/vieclam_page_banner.css?v=1.9.0">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/vieclam_page_thongke_v1_8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/vieclam_page_track-tabs_v1_9.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/vieclam_page_career_service_v1_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_custome_reset.css?v=13.2.3">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/company_page_banner.css?v=1.9.1">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/company_page_solution.css?v=1.4.2">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/company_page_investing.css?v=1.4.1">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/company_page_static_v1_5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/company_page_procedure.css?v=1.9.1">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/company_page_workforce.css?v=1.8.2">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/blog_custom_tag_v6_4.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/blog_xemChiTiet_v2_7.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_stats_style1_v1_8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/blog_custom_chuyenMuc_v2_9.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_test_system_study_v1_1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_btn_style_1_7.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/vieclam_page_scrollHorizontal_v1_8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/introduct_page_founder_v1_6.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/blog_customDetailBlog.css?v=2.9.5">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/introduct_page_logo_company_v1_3.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/introduct_page_system_myclass_v1_8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/introduct_page_tam_nhin_v1_20.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_header_custome_v3_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_thankyou_page_v2_3.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/fullsstackJava_page_banner_v1_5.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_newScrollLogo_v1_8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/fullsstackJava_page_duanthucte_v1_12.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/custom_frontend_chuyennghiep_v1_3.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_newHorizontal_test_v5_8.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/page_thu_vien_anh_v1_2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/vieclam_page_get_hire_v1_4.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/bog_fix_bug_v1_1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_testDinhHuong_v2_8.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.css" integrity="sha512-jxGmKjC/OykrTklkNK2NgnhNtKtUAADFY+rvSi3nA7dbaPRfjrSXYxHqX8iq5N6WTOntqEQZrEwW3L84sirfKQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_homePage_carousel_v3_6.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_custom_register_v3_9.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/blog_comment_v1_6.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_footerForm_v1_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/blog_custom_dropDownDanhMuc_v2_1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/custom_homePage_v1_2.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_homePage_danhSach_v3.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_homeBaBuoc_v2_3.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_listThongKe_v1_4.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_homeGallery_v1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_servicebox.css?v=1.0.5">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_careers.css?v=1.0.2">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_popup_v2.css?v=1.0.5">


<style>
.zalo-chat-widget{
   left:25px !important;
   bottom:100px !important;
}
</style>


<!--
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_3box_ver1.css">
<link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/cybercss/cyber_test_scrollHorizontal_v1_2.css">
-->
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N56M4LJ');</script>
<!-- End Google Tag Manager -->
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '2665206540474921');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=2665206540474921&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<!-- End Facebook Pixel Code -->
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '498491967837119');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=498491967837119&ev=PageView&noscript=1"
/></noscript>
<!--
<style>
.circle__snapper {display: none !important;}
</style>
-->
<!-- End Facebook Pixel Code -->

<!-- Trình Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '447322102920135');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=447322102920135&ev=PageView&noscript=1"
/></noscript>
<!--
<style>
.circle__snapper {display: none !important;}
</style>
-->
<!-- End Facebook Pixel Code -->

<!-- DOANH NGHIEP TRINH Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '811249442853786');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=811249442853786&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<!-- Facebook Pixel Code TK DOANH NGHIỆP TRINH -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '533706881132410');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=533706881132410&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->		<style>
			.hotline-phone-ring-circle {
				border-color: #dd3333;
			}
			.hotline-phone-ring-circle-fill, .hotline-phone-ring-img-circle, .hotline-bar {
				background-color: #dd3333;
			}
		</style>

				<style>
			.hotline-bar {
				background: rgb( 221, 51, 51, .7 );
			}
		</style>
		
				<meta name="theme-color"
			  content="#3d0f0e">
				<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
		
		<!--[if lte IE 8]>
		<script type="text/javascript">
			var $buoop = {
				vs: {i: 10, f: 25, o: 12.1, s: 7, n: 9}
			};

			$buoop.ol = window.onload;

			window.onload = function () {
				try {
					if ($buoop.ol) {
						$buoop.ol()
					}
				}
				catch (e) {
				}

				var e = document.createElement("script");
				e.setAttribute("type", "text/javascript");
				e.setAttribute("src", "https://browser-update.org/update.js");
				document.body.appendChild(e);
			};
		</script>
		<![endif]-->

		<!-- for IE6-8 support of HTML5 elements -->
		<!--[if lt IE 9]>
		<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
	<!-- Fallback for animating in viewport -->
	<noscript>
		<style type="text/css" media="screen">
			.zn-animateInViewport {visibility: visible;}
		</style>
	</noscript>
	
<!-- Facebook Pixel Code -->
<script type='text/javascript'>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
</script>
<!-- End Facebook Pixel Code -->
<script type='text/javascript'>
  fbq('init', '217557538587942', [], {
    "agent": "wordpress-5.0.21-1.7.25"
});
</script><script type='text/javascript'>
  fbq('track', 'PageView', []);
</script>
<!-- Facebook Pixel Code -->
<noscript>
<img height="1" width="1" style="display:none" alt="fbpx"
src="https://www.facebook.com/tr?id=217557538587942&ev=PageView&noscript=1" />
</noscript>
<!-- End Facebook Pixel Code -->
<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://cybersoft.edu.vn/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.8.1 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<style type="text/css" id="spu-css-14748" class="spu-css">		#spu-bg-14748 {
			background-color: rgba(0,0,0,0.5);
		}

		#spu-14748 .spu-close {
			font-size: 30px;
			color: #666;
			text-shadow: 0 1px 0 #000;
		}

		#spu-14748 .spu-close:hover {
			color: #000;
		}

		#spu-14748 {
			background-color: rgb(255, 255, 255);
			max-width: 460px;
			border-radius: 20px;
			
					height: auto;
					box-shadow:  0px 0px 0px 0px #ccc;
				}

		#spu-14748 .spu-container {
					padding: 0px;
			height: calc(100% - 0px);
		}
								</style>
		<link rel="icon" href="https://cybersoft.edu.vn/wp-content/uploads/2017/03/cropped-min-new-32x32.png" sizes="32x32" />
<link rel="icon" href="https://cybersoft.edu.vn/wp-content/uploads/2017/03/cropped-min-new-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://cybersoft.edu.vn/wp-content/uploads/2017/03/cropped-min-new-180x180.png" />
<meta name="msapplication-TileImage" content="https://cybersoft.edu.vn/wp-content/uploads/2017/03/cropped-min-new-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96607030-1', 'auto');
  ga('send', 'pageview');

</script>
<!-- Global site tag (gtag.js) - AdWords: 964782458 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-964782458"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-964782458');
</script><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<body data-rsssl=1  class="error404 res1170 kl-sticky-header kl-skin--light wpb-js-composer js-comp-ver-5.0.1 vc_responsive" itemscope="itemscope" itemtype="https://schema.org/WebPage" >


<div class="login_register_stuff"></div><!-- end login register stuff -->		<div id="fb-root"></div>
		<script>(function (d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s);
				js.id = id;
				js.src = "//connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js#xfbml=1&version=v2.12&autoLogAppEvents=1";
				fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));</script>
		
<div id="zn-nav-overlay" class="znNavOvr znNavOvr--layoutS3 znNavOvr--animation1 znNavOvr--theme-light">

	<div class="znNavOvr-inner ">

		<div class="znNavOvr-s3-left"><div class="hidden-lg"></div><div class="znNavOvr-menuWrapper"></div></div><div class="znNavOvr-s3-right"><div class="znNavOvr-s3-rightTop"><div class="visible-lg"></div></div><div class="znNavOvr-s3-rightBottom"></div></div>
	</div>

	<a href="#" class="znNavOvr-close znNavOvr-close--trSmall" id="znNavOvr-close">
		<span></span>
		<svg x="0px" y="0px" width="54px" height="54px" viewBox="0 0 54 54">
			<circle fill="transparent" stroke="#656e79" stroke-width="1" cx="27" cy="27" r="25" stroke-dasharray="157 157" stroke-dashoffset="157"></circle>
		</svg>
	</a>
</div>

<div id="page_wrapper">

<header id="header" class="site-header  style13 header--sticky header--not-sticked    headerstyle-xs--image_color  sticky-resize headerstyle--image_color site-header--relative nav-th--light kl-center-menu sheader-sh--light"  data-original-sticky-textscheme="sh--light"  role="banner" itemscope="itemscope" itemtype="https://schema.org/WPHeader" >
		<div class="site-header-wrapper sticky-top-area">

		<div class="site-header-top-wrapper topbar-style--custom  sh--dark">

			<div class="siteheader-container topbar-full">

				


<div class="fxb-row site-header-row site-header-top ">
    <div
        class='fxb-col fxb fxb-end-x fxb-center-y fxb-basis-auto site-header-col-right site-header-top-right'>
                <div class="sh-component zn_header_top_nav-wrapper "><span class="headernav-trigger js-toggle-class" data-target=".zn_header_top_nav-wrapper" data-target-class="is-opened"></span><ul id="menu-topbar-1" class="zn_header_top_nav topnav topnav-no-sc clearfix"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12822"><a title="DÀNH CHO DOANH NGHIỆP" href="https://cybersoft.edu.vn/danh-cho-doanh-nghiep/">DÀNH CHO DOANH NGHIỆP</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3936"><a href="https://cybersoft.edu.vn/blog/">BLOG</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1447"><a target="_blank" href="https://cyberlearn.vn">HỌC ONLINE CYBERLEARN.VN</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22"><a><a href="tel:+84961051014" class="hotline">Hotline: 0961.05.10.14</a></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-29"><a href="https://www.facebook.com/lophocviet/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9016"><a href="https://www.youtube.com/channel/UCWc3ASTJcb0FeO2oFfX8IDQ"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
</ul></div>
		<div id="search" class="sh-component header-search headsearch--min">

			<a href="#" class="searchBtn header-search-button">
				<span class="glyphicon glyphicon-search kl-icon-white"></span>
			</a>

			<div class="search-container header-search-container">
				
<form id="searchform" class="gensearch__form" action="https://cybersoft.edu.vn/" method="get">
	<input id="s" name="s" value="" class="inputbox gensearch__input" type="text" placeholder="SEARCH ..." />
	<button type="submit" id="searchsubmit" value="go" class="gensearch__submit glyphicon glyphicon-search"></button>
	</form>			</div>
		</div>

		    </div>

</div><!-- /.site-header-top -->



			</div>
		</div><!-- /.site-header-top-wrapper -->

		<div class="kl-top-header site-header-main-wrapper clearfix   header-no-bottom fxb-sm-wrap sh--light">

			<div class="container siteheader-container ">

				<div class='fxb-col fxb-basis-auto'>

					

<div class="fxb-row site-header-row site-header-main ">

    <div
        class='fxb-col fxb fxb-start-x fxb-center-y fxb-basis-auto fxb-grow-0  site-header-col-left site-header-main-left'>

        <!--start logo -->
        <div class='cyber-header-logo'><a href="/">
                <img src="/wp-content/uploads/2022/10/cyberlogo-white.png" alt="CyberSoft.edu.vn logo"
                    class="cyberlogo" /></a>
        </div>
        <!--end logo -->
        
    </div>

    <div
        class='fxb-col fxb fxb-center-x fxb-center-y fxb-basis-auto site-header-col-center site-header-main-center'>

        		<div class="sh-component main-menu-wrapper" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement" >

					<div class="zn-res-menuwrapper">
			<a href="#" class="zn-res-trigger zn-menuBurger zn-menuBurger--3--s zn-menuBurger--anim1 " id="zn-res-trigger">
				<span></span>
				<span></span>
				<span></span>
			</a>
		</div><!-- end responsive menu -->
		<div id="main-menu" class="main-nav mainnav--overlay mainnav--active-text mainnav--pointer-dash nav-mm--light zn_mega_wrapper "><ul id="menu-restaurant-menu" class="main-menu main-menu-nav zn_mega_menu "><li id="menu-item-861" class="main-menu-item base__index menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-861 menu-item-mega-parent menu-item-has-children  main-menu-item-top  menu-item-even menu-item-depth-0"><a class=" main-menu-link main-menu-link-top"><span>Khóa học <i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
<div class='zn_mega_container container'>
<div class="zn_mega_menu_container_wrapper" ><ul class="clearfix">
	<li id="menu-item-4355" class="main-menu-item base__index--one menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4355 col-sm-4 main-menu-item-sub  menu-item-odd menu-item-depth-1"><a class=" main-menu-link main-menu-link-sub zn_mega_title "><span>Học từ Zero đến có việc</span></a>
	<ul class="clearfix">
		<li id="menu-item-11237" class="main-menu-item base__index--two menu-item menu-item-type-post_type menu-item-object-page menu-item-11237  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://cybersoft.edu.vn/bai-kiem-tra-dinh-huong-nghe/" class=" main-menu-link main-menu-link-sub"><span>Bài kiểm tra định hướng nghề</span></a></li>
		<li id="menu-item-4029" class="main-menu-item base__index--two menu-item menu-item-type-post_type menu-item-object-page menu-item-4029  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a href="https://cybersoft.edu.vn/bootcamp-lap-trinh-front-end-tu-zero-co-viec-lam/" class=" main-menu-link main-menu-link-sub"><span>Bootcamp Lập trình Front-End từ Zero đến có việc</span></a></li>
		<li id="menu-item-4116" class="main-menu-item base__index--two bestseller-item menu-item menu-item-type-post_type menu-item-object-page menu-item-4116  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a href="https://cybersoft.edu.vn/bootcamp-lap-trinh-fullstack-javascript-tu-zero-co-viec-lam/" class=" main-menu-link main-menu-link-sub"><span>Bootcamp Lập trình Full-Stack <br class="break-heading">  Javascript từ Zero đến có việc</span><span class="zn-mega-new-item">Best Seller</span></a></li>
		<li id="menu-item-14014" class="main-menu-item base__index--two bestseller-item menu-item menu-item-type-post_type menu-item-object-page menu-item-14014  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a href="https://cybersoft.edu.vn/ky-su-lap-trinh-fullstack-cao-cap-tu-zero-den-duoc-tra-tien/" class=" main-menu-link main-menu-link-sub"><span>Kỹ sư lập trình Full-Stack <span class="cyberheading-highlight" >Cao Cấp</span> – Từ zero đến <span class="cyberheading-label" >được trả tiền</span></span><span class="zn-mega-new-item">Mới</span></a></li>
		<li id="menu-item-10682" class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-10682  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a href="https://cybersoft.edu.vn/bootcamp-lap-trinh-back-end-java-tu-zero-co-viec-lam/" class=" main-menu-link main-menu-link-sub"><span>Bootcamp Lập trình Back-End JAVA từ Zero đến có việc</span></a></li>
		<li id="menu-item-4360" class="main-menu-item base__index--two menu-item menu-item-type-post_type menu-item-object-page menu-item-4360  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a href="https://cybersoft.edu.vn/bootcamp-ban-ngay-lap-trinh-fullstack-javascript-tu-zero-co-viec-lam/" class=" main-menu-link main-menu-link-sub"><span>Bootcamp Lập trình Full-Stack Javascript từ Zero đến có việc <span class="menu-impressed">(học cấp tốc)</span></span></a></li>
		<li id="menu-item-13762" class="main-menu-item base__index--two menu-item menu-item-type-custom menu-item-object-custom menu-item-13762  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/lo-trinh/software-engineering-nguoi-lon/" class=" main-menu-link main-menu-link-sub"><span>Bootcamp Full-time Web &#038; Mobile &#038; Devops <span class="menu-impressed">(chương trình mới)</span></span></a></li>
		<li id="menu-item-5086" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-5086  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://cyberlab.edu.vn" class=" main-menu-link main-menu-link-sub"><span>Phân tích dữ liệu / Data Analysis / Data Science / AI</span></a></li>
		<li id="menu-item-3897" class="main-menu-item base__index--two menu-item menu-item-type-custom menu-item-object-custom menu-item-3897  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://cyberlearn.vn" class=" main-menu-link main-menu-link-sub"><span>Học lập trình online video</span></a></li>
	</ul>
</li>
	<li id="menu-item-4356" class="main-menu-item base__index--one menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4356 col-sm-4 main-menu-item-sub  menu-item-odd menu-item-depth-1"><a class=" main-menu-link main-menu-link-sub zn_mega_title "><span>Nâng cấp kỹ năng</span></a>
	<ul class="clearfix">
		<li id="menu-item-2501" class="main-menu-item base__index--two menu-item menu-item-type-post_type menu-item-object-page menu-item-2501  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a href="https://cybersoft.edu.vn/lap-trinh-back-end-nodejs-viet-api-thuc-te/" class=" main-menu-link main-menu-link-sub"><span>Lập trình Back-End viết API với NodeJS</span></a></li>
		<li id="menu-item-14091" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-14091  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a href="https://techx.edu.vn/khoa-hoc/cap-3-va-nguoi-lon/khoa-hoc-may-tinh-02/" class=" main-menu-link main-menu-link-sub"><span>Lập trình hướng đối tượng thực tế &#038; Big-O</span></a></li>
		<li id="menu-item-13700" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-13700  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/khoa-hoc/cap-3-va-nguoi-lon/khoa-hoc-may-tinh-03-pre/" class=" main-menu-link main-menu-link-sub"><span>Cấu trúc dữ liệu &#038; thuật toán phổ biến (Python &#038; Java)</span></a></li>
		<li id="menu-item-14090" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-14090  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/khoa-hoc/cap-3-va-nguoi-lon/khoa-hoc-may-tinh-03-lux/" class=" main-menu-link main-menu-link-sub"><span>Cấu trúc dữ liệu &#038; thuật toán cao cấp (Python &#038; Java)</span></a></li>
		<li id="menu-item-14136" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-14136  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/khoa-hoc/chuyen-gia-lap-trinh-mobile-app-react-native/" class=" main-menu-link main-menu-link-sub"><span>Chuyên gia lập trình mobile app React Native</span></a></li>
	</ul>
</li>
	<li id="menu-item-10333" class="main-menu-item base__index--one menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10333 col-sm-4 main-menu-item-sub  menu-item-odd menu-item-depth-1"><a class=" main-menu-link main-menu-link-sub zn_mega_title "><span>Trường Lập Trình &#038; Công nghệ <img class="techx-menu" src="https://cybersoft.edu.vn/wp-content/uploads/2023/08/logo-techX-menu.png"/> <span class="techX-badges">Chương trình mới</span></span></a>
	<ul class="clearfix">
		<li id="menu-item-13667" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-13667  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/lo-trinh/computer-science-nguoi-lon/" class=" main-menu-link main-menu-link-sub"><span>Khoa học máy tính THPT &#038; người lớn</span></a></li>
		<li id="menu-item-13668" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-13668  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/lo-trinh/software-engineering-nguoi-lon/" class=" main-menu-link main-menu-link-sub"><span>Kỹ sư phần mềm THPT &#038; người lớn</span></a></li>
		<li id="menu-item-13671" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-13671  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/khoa-hoc/cap-3-va-nguoi-lon/khoa-hoc-may-tinh-01/" class=" main-menu-link main-menu-link-sub"><span>Tư duy lập trình &#038; thuật toán nền tảng (Python &#038; Game)</span></a></li>
		<li id="menu-item-13672" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-13672  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/khoa-hoc/cap-3-va-nguoi-lon/khoa-hoc-may-tinh-02/" class=" main-menu-link main-menu-link-sub"><span>Lập trình hướng đối tượng nền tảng chuyên sâu (Python &#038; Java)</span></a></li>
		<li id="menu-item-13673" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-13673  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/khoa-hoc/cap-3-va-nguoi-lon/khoa-hoc-may-tinh-03/" class=" main-menu-link main-menu-link-sub"><span>Cấu trúc dữ liệu &#038; thuật toán chuyên sâu (Python &#038; Java)</span></a></li>
		<li id="menu-item-13669" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-13669  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/lo-trinh/computer-science-cap-2/" class=" main-menu-link main-menu-link-sub"><span>Khoa học máy tính trẻ em (10-15 tuổi)</span></a></li>
		<li id="menu-item-13670" class="main-menu-item menu-item menu-item-type-custom menu-item-object-custom menu-item-13670  main-menu-item-sub main-menu-item-sub-sub menu-item-even menu-item-depth-2"><a target="_blank" href="https://techx.edu.vn/lo-trinh/software-engineering-cap-2/" class=" main-menu-link main-menu-link-sub"><span>Kỹ sư phần mềm trẻ em (10-15 tuổi)</span></a></li>
	</ul>
</li>
</ul>
</div></div></li>
<li id="menu-item-570" class="main-menu-item base__index menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-570  main-menu-item-top  menu-item-even menu-item-depth-0"><a class=" main-menu-link main-menu-link-top"><span>Góc học viên  <i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
<ul class="sub-menu clearfix">
	<li id="menu-item-3132" class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-3132  main-menu-item-sub  menu-item-odd menu-item-depth-1"><a href="https://cybersoft.edu.vn/stories/" class=" main-menu-link main-menu-link-sub"><span>Stories</span></a></li>
	<li id="menu-item-228" class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-228  main-menu-item-sub  menu-item-odd menu-item-depth-1"><a href="https://cybersoft.edu.vn/thu-vien-anh/" class=" main-menu-link main-menu-link-sub"><span>Thư viện ảnh</span></a></li>
	<li id="menu-item-8184" class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-8184  main-menu-item-sub  menu-item-odd menu-item-depth-1"><a href="https://cybersoft.edu.vn/cam-nhan-hoc-vien/" class=" main-menu-link main-menu-link-sub"><span>Cảm nhận học viên</span></a></li>
</ul>
</li>
<li id="menu-item-12824" class="main-menu-item base__index menu-item menu-item-type-post_type menu-item-object-page menu-item-12824  main-menu-item-top  menu-item-even menu-item-depth-0"><a href="https://cybersoft.edu.vn/cam-ket-dau-ra/" class=" main-menu-link main-menu-link-top"><span>Cam kết đầu ra</span></a></li>
<li id="menu-item-3899" class="main-menu-item base__index menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-3899  main-menu-item-top  menu-item-even menu-item-depth-0"><a class=" main-menu-link main-menu-link-top"><span>Về CyberSoft <i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
<ul class="sub-menu clearfix">
	<li id="menu-item-12511" class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-12511  main-menu-item-sub  menu-item-odd menu-item-depth-1"><a href="https://cybersoft.edu.vn/gioi-thieu-cybersoft/" class=" main-menu-link main-menu-link-sub"><span>Giới thiệu</span></a></li>
	<li id="menu-item-225" class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-225  main-menu-item-sub  menu-item-odd menu-item-depth-1"><a href="https://cybersoft.edu.vn/lien-he/" class=" main-menu-link main-menu-link-sub"><span>Liên hệ</span></a></li>
	<li id="menu-item-13240" class="main-menu-item menu-item menu-item-type-post_type menu-item-object-page menu-item-13240  main-menu-item-sub  menu-item-odd menu-item-depth-1"><a href="https://cybersoft.edu.vn/thong-tin-cong-bo-mao-danh-cybersoft/" class=" main-menu-link main-menu-link-sub"><span>Thông tin công bố mạo danh CyberSoft</span></a></li>
</ul>
</li>
<li id="menu-item-12825" class="main-menu-item cyber-menu-mobile menu-item menu-item-type-custom menu-item-object-custom menu-item-12825  main-menu-item-top  menu-item-even menu-item-depth-0"><a href="https://cybersoft.edu.vn/danh-cho-doanh-nghiep/" class=" main-menu-link main-menu-link-top"><span>Dành cho doanh nghiệp</span></a></li>
<li id="menu-item-11954" class="main-menu-item cyber-menu-mobile menu-item menu-item-type-custom menu-item-object-custom menu-item-11954  main-menu-item-top  menu-item-even menu-item-depth-0"><a href="https://cybersoft.edu.vn/blog/" class=" main-menu-link main-menu-link-top"><span>Bài viết</span></a></li>
<li id="menu-item-11955" class="main-menu-item cyber-menu-mobile menu-item menu-item-type-custom menu-item-object-custom menu-item-11955  main-menu-item-top  menu-item-even menu-item-depth-0"><a target="_blank" href="https://cyberlearn.vn/" class=" main-menu-link main-menu-link-top"><span>Học online cyberlearn.vn</span></a></li>
<li id="menu-item-11973" class="main-menu-item cyber-menu-mobile menu-item menu-item-type-custom menu-item-object-custom menu-item-11973  main-menu-item-top  menu-item-even menu-item-depth-0"><a href="tel:+84961051014" class=" main-menu-link main-menu-link-top"><span>Hotline: 0961.05.10.14</span></a></li>
<li id="menu-item-4361" class="main-menu-item mnudky menu-item menu-item-type-custom menu-item-object-custom menu-item-4361  main-menu-item-top  menu-item-even menu-item-depth-0"><a target="_blank" href="https://www.facebook.com/lophocviet/" class=" main-menu-link main-menu-link-top"><span>INBOX TƯ VẤN 1-1</span></a></li>
</ul></div>		</div>
		<!-- end main_menu -->
		    </div>

    <div
        class='fxb-col fxb fxb-end-x fxb-center-y fxb-basis-auto fxb-grow-0  site-header-col-right site-header-main-right'>

        <div
            class='fxb-col fxb fxb-end-x fxb-center-y fxb-basis-auto fxb-grow-0  site-header-main-right-top'>
                                </div>

        
    </div>

</div><!-- /.site-header-main -->


				</div>

							</div><!-- /.siteheader-container -->

		</div><!-- /.site-header-main-wrapper -->

		

	</div><!-- /.site-header-wrapper -->
	</header>
	<div class="error404-page">

		<section id="content" class="site-content" >
			<div class="container">

				<div id="mainbody">

					<div class="row">
						<div class="col-sm-12">

							<div class="error404-content">
								<h2 class="error404-content-title" itemprop="headline" ><span>404</span></h2>
								<h3 class="error404-content-msg">The page cannot be found.</h3>
							</div>

						</div>

						<div class="col-sm-12">
							<div class="search gensearch__wrapper kl-gensearch--light">
								
<form id="searchform" class="gensearch__form" action="https://cybersoft.edu.vn/" method="get">
	<input id="s" name="s" value="" class="inputbox gensearch__input" type="text" placeholder="SEARCH ..." />
	<button type="submit" id="searchsubmit" value="go" class="gensearch__submit glyphicon glyphicon-search"></button>
	</form>							</div>
						</div>
					</div><!-- end row -->

				</div><!-- end mainbody -->

			</div><!-- end container -->
		</section><!-- end #content -->
	</div>


	<footer id="footer" class="site-footer"  role="contentinfo" itemscope="itemscope" itemtype="https://schema.org/WPFooter" >
		<div class="container">
			<div class="row"><div class="col-sm-4"><div id="text-14" class="widget widget_text"><h3 class="widgettitle title m_title m_title_ext text-custom">Đăng ký nhận Ưu đãi &#038; Bài viết mới</h3>			<div class="textwidget"><p>CyberSoft sẽ gởi các khóa học trực tuyến &amp; các chương trình CyberLive hoàn toàn MIỄN PHÍ và các chương trình KHUYẾN MÃI hấp dẫn đến các bạn.</p>
<div><div id="dhvcform-13116"  class="dhvc-form-container dhvc-form-icon-pos-right dhvc-form-vertical dhvc-form-flat">
<div class="dhvc-form-message dhvc-form-message-top" style="display:none"></div>
<form novalidate data-currency="USD" data-currency_symbol="&#036;" data-price_format="%s%v"   data-scroll_to_msg="1" data-ajax_reset_submit="1" data-popup="0" autocomplete="off" data-use-ajax="1" method="post" class="dhvcform dhvcform-13116 dhvcform-action-default" enctype="multipart/form-data" target="_self" >
<div class="dhvc-form-inner">
<div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="dhvc-form-group dhvc-form-email-box dhvc_form_email ">
<div class="dhvc-form-input  dhvc-form-has-add-on">
<input data-field-name="email" autocomplete="off" type="email" id="dhvc_form_control_email" name="email" value=""  class="dhvc-form-control dhvc-form-control-email dhvc-form-value dhvc-form-required-entry dhvc-form-validate-email  "  required aria-required="true"  placeholder="Email liên hệ *" >
<span class="dhvc-form-add-on"><i class="fa fa-envelope"></i></span>
</div></div>
<div class="vc_empty_space"  style="height: 15px" ><span class="vc_empty_space_inner"></span></div>
<div class="dhvc-form-group dhvc-form-sodienthoai-box dhvc_form_text ">
<div class="dhvc-form-input  dhvc-form-has-add-on">
<input data-field-name="sodienthoai" autocomplete="off" type="text" id="dhvc_form_control_sodienthoai" name="sodienthoai" value=""  minlength="8"  class="dhvc-form-control dhvc-form-control-sodienthoai dhvc-form-value dhvc-form-required-entry dhvc-form-validate-number2"  required aria-required="true"  placeholder="Điện thoại liên hệ *" >
<span class="dhvc-form-add-on"><i class="fa fa-phone"></i></span>
</div></div>
<div class="vc_empty_space"  style="height: 15px" ><span class="vc_empty_space_inner"></span></div>
<div class="dhvc-form-group dhvc-form-capchar3-box dhvc_form_recaptcha ">
<label class="dhvc-form-label" for="capchar3">Nhấn chọn vào ô bên dưới <span class="required">*</span></label>
<div type="recaptcha" data-dhvcform-recaptcha="recaptcha" class="dhvc-form-recaptcha dhvc-form-recaptcha2" data-name="capchar3" id="capchar3"></div>
	<noscript>
		<div style="width: 302px; height: 422px;">
			<div style="width: 302px; height: 422px; position: relative;">
				<div style="width: 302px; height: 422px; position: absolute;">
					<iframe src="https://www.google.com/recaptcha/api/fallback?k=6LeIqm8lAAAAAKiIhzHXxhobyeCocIhdyjsvNTZt" frameborder="0" scrolling="no" style="width:100%; height:422px; border-style: none;">
					</iframe>
				</div>
				<div style="width: 300px; height: 60px; border-style: none; bottom: 12px; left: 25px; margin: 0px; padding: 0px; right: 25px; background: #f9f9f9; border: 1px solid #c1c1c1; border-radius: 3px;">
					<textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid #c1c1c1; margin: 10px 25px; padding: 0px; resize: none;">
					</textarea>
				</div>
			</div>
		</div>
	</noscript></div>

<div class="dhvc-form-action dhvc_form_submit_button ">
	<button type="submit" class="button dhvc-form-submit">
		<span class="dhvc-form-submit-label">ĐĂNG KÝ NGAY</span>
		<span class="dhvc-form-submit-spinner">
			<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="25 25 50 50"  xml:space="preserve">
				<circle class="path" cx="50" cy="50" r="20" stroke-dasharray="89, 200" stroke="currentColor" stroke-dashoffset="-35" fill="none" stroke-width="5" stroke-miterlimit="10"/>
			</svg>
		</span>
	</button>
</div></div></div></div></div></div><div style="display: none;">
<input type="hidden" name="action" value="dhvc_form_ajax">
<input type="hidden" id="_dhvc_form_hidden_fields" name="_dhvc_form_hidden_fields" value="">
<input type="hidden" name="_dhvc_form_id" value="13116">
<input type="hidden" name="_dhvc_form_url" value="https://cybersoft.edu.vn/signals/iwl.js">
<input type="hidden" name="_dhvc_form_referer" value="http://connect.facebook.net/en_US/fbevents.js">
<input type="hidden" name="_dhvc_form_post_id" value="">
<input type="hidden" name="_dhvc_form_nonce" value="1714152e2f">
</div>
</form>
</div>
</div>
</div>
		</div></div><div class="col-sm-4"><div id="text-8" class="widget widget_text">			<div class="textwidget"><div style="text-align:center;">
<a class="menudk"  href="https://www.facebook.com/lophocviet/" target="_blank" rel="noopener"><span>TƯ VẤN &amp; ĐĂNG KÝ HỌC</span><i class="fa fa-angle-right" aria-hidden="true"></i></a>
</div>
</div>
		</div></div><div class="col-sm-4"><div id="simple_facebook_page_feed_widget-3" class="widget widget_simple_facebook_page_feed_widget"><!-- This Facebook Page Feed was generated with Simple Facebook Page Widget & Shortcode plugin v1.5.0 - https://wordpress.org/plugins/simple-facebook-twitter-widget/ --><div id="simple-facebook-widget" style="text-align:center;"><div class="fb-page" data-href="https://www.facebook.com/lophocviet/" data-width="340" data-height="325" data-tabs="timeline" data-hide-cover="0" data-show-facepile="0" data-hide-cta="0" data-small-header="0" data-adapt-container-width="1"></div></div><!-- End Simple Facebook Page Plugin (Widget) --></div></div></div><!-- end row --><div class="row"><div class="col-sm-4"><div id="text-9" class="widget widget_text">			<div class="textwidget"></div>
		</div></div><div class="col-sm-4"><div id="text-12" class="widget widget_text">			<div class="textwidget"><div class="cyber__locations">
<div class="cyber__locations--wrapper">
<h2 class="city">TP. Hồ Chí Minh</h2>
<div class="cyber__locations--inner">
<div class="inner__item">
<h3 class="place">Trụ sở: 2Bis Nguyễn Thị Minh Khai, Quận 1</h3>
<h6>Hotline: 096.105.1014</h6>
<h6>Địa chỉ: 2Bis Nguyễn Thị Minh Khai, Quận 1, TPHCM</h6>
</div>
<div class="inner__item">
<h3 class="place">112 Cao Thắng, Quận 3</h3>
<h6>Hotline: 096.105.1014</h6>
<h6>Địa chỉ: Tầng 5, toà nhà Suri, 112 Cao Thắng, Quận 3, TPHCM</h6>
</div>
<div class="inner__item">
<h3 class="place">P3-00.05 Chung cư Cityland Park Hills, Phường 10, Quận Gò Vấp</h3>
<h6>Hotline: 096.105.1014</h6>
<h6>Địa chỉ: P3-00.05 Chung cư Cityland Park Hills, Phường 10, Quận Gò Vấp, TP.HCM</h6>
</div>
<div class="inner__item">
<h3 class="place">6C Đường số 8, Linh Tây, Thủ Đức (gần ĐH Cảnh Sát)</h3>
<h6>Hotline: 096.105.1014</h6>
<h6>Địa chỉ: 6C Đường số 8, Linh Tây, Thủ Đức, TPHCM</h6>
</div>
</div>
</div>
<div class="cyber__locations--wrapper cyber__locations--wrapper2">
<div>
<h2 class="city">Đà Nẵng</h2>
<div class="cyber__locations--inner">
<div class="inner__item">
<h3 class="place">103 Nguyễn Hữu Dật, Hải Châu</h3>
<h6>Hotline: 096.105.1014</h6>
<h6>Địa chỉ: 103 Nguyễn Hữu Dật, Hải Châu, ĐN</h6>
</div>
</div>
</div>
<div>
<div class="cyber__locations--inner">
<div class="inner__item">
<h6></h6>
</div>
</div>
</div>
</div>
</div>
</div>
		</div></div><div class="col-sm-4"><div id="text-10" class="widget widget_text">			<div class="textwidget"></div>
		</div></div></div><!-- end row -->
			<div class="row">
				<div class="col-sm-12">
					<div class="bottom site-footer-bottom clearfix">

						
						<ul class="social-icons sc--colored clearfix"><li class="social-icons-li title">GET SOCIAL</li><li class="social-icons-li"><a data-zniconfam="kl-social-icons" data-zn_icon="" href="https://www.facebook.com/lophocviet/" target="_blank" title="" class="social-icons-item scfooter-icon-ue83f"></a></li><li class="social-icons-li"><a data-zniconfam="kl-social-icons" data-zn_icon="" href="https://www.youtube.com/channel/UCWc3ASTJcb0FeO2oFfX8IDQ" target="_blank" title="" class="social-icons-item scfooter-icon-ue842"></a></li></ul>
						
							<div class="copyright footer-copyright">
								<p class="footer-copyright-text"><div class="sub__footer--container">
<div class="sub__footer--copyright">
© Bản quyền CyberSoft 2017 - 2023 - Empower by <a href="https://cybersoft.edu.vn" target="_blank">CyberSoft</a>
</div>
<div class="sub__footer--tags">
<a href="https://cybersoft.edu.vn/bootcamp-lap-trinh-front-end-tu-zero-co-viec-lam/" target="_blank" rel="noopener">Bootcamp Lập trình Front-End</a>    <a href="https://cybersoft.edu.vn/bootcamp-lap-trinh-fullstack-javascript-tu-zero-co-viec-lam/" target="_blank" rel="noopener">Bootcamp Full-Stack Javascript</a>      <a href="https://cybersoft.edu.vn/bootcamp-lap-trinh-back-end-java-tu-zero-co-viec-lam/" target="_blank" rel="noopener">Bootcamp Java Back-End</a>   <a href="https://techx.edu.vn/khoa-hoc/cap-3-va-nguoi-lon/khoa-hoc-may-tinh-01/" target="_blank" rel="noopener">Tư duy lập trình, Thuật toán</a>   <a href="https://techx.edu.vn/khoa-hoc/cap-3-va-nguoi-lon/khoa-hoc-may-tinh-03/" target="_blank" rel="noopener">Cấu trúc dữ liệu, Thuật toán nâng cao</a>  <a href="https://cyberlab.edu.vn/phan-tich-du-lieu-voi-python/" target="_blank" rel="noopener">Phân tích Dữ liệu với Python</a> 
</div>
</div>
</p>							</div><!-- end copyright -->
											</div>
					<!-- end bottom -->
				</div>
			</div>
			<!-- end row -->
		</div>
	</footer>
</div><!-- end page_wrapper -->

<a href="#" id="totop" class="u-trans-all-2s js-scroll-event" data-forch="300" data-visibleclass="on--totop">TOP</a>

        <div id="fb-root"></div>
        <script async defer crossorigin="anonymous">(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&appId=825304329017984&version=v10.0";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>	
    
			<script>(function(d, s, id) {
			var js, fjs = d.getElementsByTagName(s)[0];
			js = d.createElement(s); js.id = id;
			js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js#xfbml=1&version=v6.0&autoLogAppEvents=1'
			fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));</script>
			<div class="fb-customerchat" attribution="wordpress" attribution_version="2.3" page_id="231169113737422"></div>

			<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script__menucircle_v10.js"></script>

<!-- New Script -->
 <script src="https://cybersoft.edu.vn/wp-content/cyberjs/cyber_aos.js"></script>
    <script>
        AOS.init({
          once: true,
        });
    </script>

<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_different_v4_6.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_courseOutput_v1_7.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_project_v3_5.js"></script>
<script type="module" src="https://cybersoft.edu.vn/wp-content/cyberjs/vanilla-tilt.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/slick.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/slick.setting_v3.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/cyber_cards_stack_v1.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_introduce_course_v12.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_resignter_v1.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/cyber_fancyBox.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_feedback_company_review_v2.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_system_study_v1_10.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_vieclam_page_thongke_v1_2.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_vieclam_page_track-tabs_v1_5.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_company_page_procedure_v1_2.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_company_page_static_v1_6.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_test_system_study_v1_6.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_blog_subStr_v4_1.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_vieclam_page_scrollHorizontal_v1_5.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_introduct_NumberRun_v1_3.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_slick_test_v1_4.css"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/page_blog_fix_bug_v1_3.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_vieclam_page_get_hire_v1_2.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_test_scrollHorizontal_v3_7.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_getValueUserRegister_v22.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/cyber_testDinhHuong_v3_2.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/8.4.5/swiper-bundle.min.js" integrity="sha512-wdUM0BxMyMC/Yem1RWDiIiXA6ssXMoxypihVEwxDc+ftznGeRu4s9Fmxl8PthpxOh5CQ0eqjqw1Q8ScgNA1moQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_carousel_homepage_v4_4.js"></script>
 <script src="https://cybersoft.edu.vn/wp-content/cyberjs/accordionClass_v01.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_blogChiTiet_v1_1.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_blog_comment_v1.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_socialShare_v1_1.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_blog_formSideBar_v1_4.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_footerForm_v1_2.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/blog_custom_dropDownDanhMuc_v2_1.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_getValueFormCompany_v1_1.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_getValueBanner_v1_4.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_cyber_getValuePopup_v2_1.js"></script>


	
	

<!-- Axios -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/1.1.3/axios.min.js"
    integrity="sha512-0qU9M9jfqPw6FKkPafM3gy2CBAvUWnYVOfNPDYKVuRTel1PrciTj+a9P3loJB+j0QmN2Y0JYQmkBBS8W+mbezg=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

 
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_countupMain_v1.js"></script>
<script src="https://cybersoft.edu.vn/wp-content/cyberjs/script_countUpThongKeHome_v1_6.js"></script>

<!-- Event snippet for Thử chuỷển đổi conversion page -->

<script>
  gtag('event', 'conversion', {'send_to': 'AW-964782458/KLMiCKT9u5cBEPrShcwD'});
</script>

<script id="mcjs">!function(c,h,i,m,p){m=c.createElement(h),p=c.getElementsByTagName(h)[0],m.async=1,m.src=i,p.parentNode.insertBefore(m,p)}(document,"script","https://chimpstatic.com/mcjs-connected/js/users/aeaecbfa092cc1f7749fa8737/c059b04d633c000c8fd765f57.js");</script>

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N56M4LJ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<script>
const itemAnchorHeader = document.createElement("A");
itemAnchorHeader.href = "https://cybersoft.edu.vn/";

let itemImgHeader = document.createElement("IMG");
itemImgHeader.src = "https://cybersoft.edu.vn/wp-content/uploads/2021/03/logo-cyber-nav.svg";
itemImgHeader.classList.add("img__logo--navbar");


itemAnchorHeader.appendChild(itemImgHeader);
document.querySelector(".site-header-main-wrapper .siteheader-container .site-header-col-center.site-header-main-center").appendChild(itemAnchorHeader);
</script>

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WMLCHPL"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MRDX48P"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->


<div class="zalo-chat-widget" data-oaid="1427277038490183753" data-welcome-message="Rất vui khi được hỗ trợ bạn!" data-autopopup="0" data-width="" data-height=""></div>

<script src="https://sp.zalo.me/plugins/sdk.js"></script><div id="wow-modal-overlay-1" class="wow-modal-overlay" style="display:none;"><div id="wow-modal-overclose-1" class="wow-modal-overclose"></div><div id="wow-modal-window-1" class="wow-modal-window" style="display:none;"><div id="wow-modal-close-1" class="mw-close-btn topRight text"></div><div class="modal-window-content"><div class="wow-modal__header">
<h4>Chương trình giảng dạy Elearning</h4>
</div>
<div class="wow-modal__content"><!-- Task start -->
<div class="capstone__curri__box">
<h4>Starter</h4>
<ul>
<li>Project về gì?</li>
<li>Workflow và đặc tả dự án</li>
</ul>
</div>
<!-- Task 1 -->
<div class="capstone__curri__box">
<h4>Task 1: Khởi tạo dự án</h4>
<ul>
<li>Khởi tạo project React/Angular</li>
<li>Thao tác thử trên Postman</li>
<li>Tạo cấu trúc thư mục</li>
<li>Thêm thư viện UI (MaterialUI/AntDesign/…)</li>
</ul>
</div>
<!-- Task 2 -->
<div class="capstone__curri__box">
<h4>Task 2: Bắt đầu dự án (Trang chủ)</h4>
<ul>
<li>Tạo header và footer cho giao diện người dùng</li>
<li>Tạo trang chủ/li&gt;</li>
<li>Thực hiện chức năng hiện Danh sách các khóa học và Danh mục</li>
</ul>
</div>
<!-- Task 3 -->
<div class="capstone__curri__box">
<h4>Task 3: Đăng kí/Đăng nhập</h4>
<ul>
<li>Tạo cấu trúc đường dẫn URL tới các trang</li>
<li>Tạo form Đăng ký/Đăng nhập</li>
<li>Validate cho form Đăng ký/Đăng nhập</li>
<li>Thực hiện chức năng cho Đăng ký/Đăng nhập</li>
</ul>
</div>
<!-- Task 4 -->
<div class="capstone__curri__box">
<h4>Task 4: Khóa học</h4>
<ul>
<li>Tạo trang Các khóa học</li>
<li>Thực hiện chức năng hiện Danh sách các khóa học và Danh mục</li>
<li>Tạo trang Chi tiết khóa học</li>
<li>Thực hiện chức năng hiện Chi tiết khóa học</li>
<li>Thực hiện chức năng Đăng ký khóa học</li>
</ul>
</div>
<!-- Task 5 -->
<div class="capstone__curri__box">
<h4>Task 5: Người dùng</h4>
<ul>
<li>Tạo trang Thông tin người dùng</li>
<li>Thực hiện chức năng Hiện thông tin người dùng</li>
<li>Thực hiện chức năng Sửa thông tin người dùng</li>
</ul>
</div>
<!-- Task 6 -->
<div class="capstone__curri__box">
<h4>Task 6: Khởi tạo trang Quản trị</h4>
<ul>
<li>Tạo layout Dashboard cho Quản trị</li>
<li>Tạo sidebar chứa Dashboard, trang Quản lí khóa học, và trang Quản lí người dùng</li>
<li>Tạo cấu trúc đường dẫn URL tới các trang</li>
</ul>
</div>
<!-- Task 7 -->
<div class="capstone__curri__box">
<h4>Task 7: Dashboard</h4>
<ul>
<li>Hiện thông tin của admin hiện tại</li>
<li>Hiện pie chart cho dữ liệu của Các khóa học và Người dùng</li>
</ul>
</div>
<!-- Task 8 -->
<div class="capstone__curri__box">
<h4>Task 8: Quản lí người dùng</h4>
<ul>
<li>Tạo trang quản lí người dùng</li>
<li>Tạo Pagination Table cho Danh sách người dùng</li>
<li>Thực hiện chức năng hiện Danh sách người dùng</li>
<li>Thực hiện chức năng Thêm, Xóa, Sửa người dùng</li>
<li>Tạo filter và chức năng Tìm kiếm người dùng</li>
</ul>
</div>
<!-- Task 9 -->
<div class="capstone__curri__box">
<h4>Task 9: Quản lí khóa học</h4>
<ul>
<li>Tạo trang quản lí khóa học</li>
<li>Tạo Pagination Table cho Danh sách các khóa học</li>
<li>Thực hiện chức năng hiện Danh sách khóa học</li>
<li>Thực hiện chức năng Thêm, Xóa, Sửa khóa học</li>
<li>Thực hiện chức năng lấy Danh sách người dùng đã/đang chờ xét duyệt ghi danh</li>
<li>Thực hiện chức năng Ghi danh khóa học</li>
<li>Thực hiện chức năng Hủy ghi danh</li>
<li>Tạo filter và chức năng Tìm kiếm khóa học</li>
</ul>
</div>
</div>
<div class="wow-modal__footer"> </div></div></div></div><div id="wow-modal-overlay-2" class="wow-modal-overlay" style="display:none;"><div id="wow-modal-overclose-2" class="wow-modal-overclose"></div><div id="wow-modal-window-2" class="wow-modal-window" style="display:none;"><div id="wow-modal-close-2" class="mw-close-btn topRight text"></div><div class="modal-window-content"><div class="wow-modal__header">
<h4>Chương trình giảng dạy Movie</h4>
</div>
<div class="wow-modal__content"><!-- Task start -->
<div class="capstone__curri__box">
<h4>Starter</h4>
<ul>
<li>Project về gì?</li>
<li>Workflow và đặc tả dự án</li>
</ul>
</div>
<!-- Task 1 -->
<div class="capstone__curri__box">
<h4>Task 1: Khởi tạo dự án</h4>
<ul>
<li>Khởi tạo project React/Angular</li>
<li>Thao tác thử trên Postman</li>
<li>Tạo cấu trúc thư mục</li>
<li>Thêm thư viện UI (MaterialUI/AntDesign/…)</li>
</ul>
</div>
<!-- Task 2 -->
<div class="capstone__curri__box">
<h4>Task 2: Bắt đầu dự án (Trang chủ)</h4>
<ul>
<li>Tạo header và footer cho giao diện người dùng</li>
<li>Tạo trang chủ/li&gt;</li>
<li>Thực hiện chức năng hiện Danh sách các phim tại trang chủ</li>
<li>Thực hiện chức năng hiện Danh sách lịch chiếu tại trang chủ</li>
</ul>
</div>
<!-- Task 3 -->
<div class="capstone__curri__box">
<h4>Task 3: Đăng kí/Đăng nhập</h4>
<ul>
<li>Tạo cấu trúc đường dẫn URL tới các trang</li>
<li>Tạo form Đăng ký/Đăng nhập</li>
<li>Validate cho form Đăng ký/Đăng nhập</li>
<li>Thực hiện chức năng cho Đăng ký/Đăng nhập</li>
</ul>
</div>
<!-- Task 4 -->
<div class="capstone__curri__box">
<h4>Task 4: Phim</h4>
<ul>
<li>Tạo trang Chi tiết phim</li>
<li>Thực hiện chức năng hiện Chi tiết phim/li>
<li>Thực hiện chức năng hiện Lịch chiếu của phim tại các rạp</li>
<li>Thực hiện chức năng bình luận</li>
</ul>
</div>
<!-- Task 5 -->
<div class="capstone__curri__box">
<h4>Task 5: Người dùng</h4>
<ul>
<li>Tạo trang Thông tin người dùng</li>
<li>Thực hiện chức năng Hiện thông tin người dùng</li>
<li>Thực hiện chức năng Sửa thông tin người dùng</li>
</ul>
</div>
<!-- Task 6 -->
<div class="capstone__curri__box">
<h4>Task 6: Khởi tạo trang Quản trị</h4>
<ul>
<li>Tạo layout Dashboard cho Quản trị</li>
<li>Tạo sidebar chứa Dashboard, trang Quản lí phim, lịch chiếu, và người dùng</li>
<li>Tạo cấu trúc đường dẫn URL tới các trang</li>
</ul>
</div>
<!-- Task 7 -->
<div class="capstone__curri__box">
<h4>Task 7: Dashboard</h4>
<ul>
<li>Hiện thông tin của admin hiện tại</li>
<li>Hiện pie chart cho dữ liệu của lịch chiếu, phim, và người dùng</li>
</ul>
</div>
<!-- Task 8 -->
<div class="capstone__curri__box">
<h4>Task 8: Quản lí người dùng</h4>
<ul>
<li>Tạo trang quản lí người dùng</li>
<li>Tạo Pagination Table cho Danh sách người dùng</li>
<li>Thực hiện chức năng hiện Danh sách người dùng</li>
<li>Thực hiện chức năng Thêm, Xóa, Sửa người dùng</li>
<li>Tạo filter và chức năng Tìm kiếm người dùng</li>
</ul>
</div>
<!-- Task 9 -->
<div class="capstone__curri__box">
<h4>Task 9: Quản lí phim</h4>
<ul>
<li>Tạo trang quản lí phim</li>
<li>Tạo Pagination Table cho Danh sách các bộ phim</li>
<li>Thực hiện chức năng Thêm, Xóa, Sửa phim</li>
<li>Tạo filter và chức năng Tìm kiếm phim</li>
</ul>
</div>
<!-- Task 10 -->
<div class="capstone__curri__box">
<h4>Task 9: Quản lí lịch chiếu</h4>
<ul>
<li>Tạo trang quản lí lịch chiếu</li>
<li>Tạo Pagination Table cho Danh sách các lịch chiếu theo cụm rạp</li>
<li>Thực hiện chức năng Thêm, Xóa, Sửa lịch chiếu</li>
<li>Tạo filter và chức năng Tìm kiếm lịch chiếu theo phim</li>
</ul>
</div>
</div>
<div class="wow-modal__footer"> </div></div></div></div>            <div class="wpfm-floating-wh-wrapper " >
                             <div class="wpfm-menu-wrapper wpfm-71438 wpfm-template-1">
            <nav id="wpfm-floating-menu-nav" class="wpfm-menu-nav wpfm wpfm-position-right">
                <ul>
                                                    <li class=" ">
                                    <a title="" class="wpfm-menu-link" href="https://cybersoft.edu.vn/danh-sach-khoa-hoc/"    >
                                                                                    <span class='wpfm-icon-block '>                
                                                                                                          <i  class="dashicons dashicons-menu" aria-hidden="true"></i>          
                                            </span>
                                                                                            <span class='name wpfm-menu-name'>
                                                    Danh sách khóa học                                                </span>
                                                                                                   
                                    </a>
                                                                    </li>
                                                                <li class=" ">
                                    <a title="" class="wpfm-menu-link" href="https://cybersoft.edu.vn/lo-trinh-hoc/"    >
                                                                                    <span class='wpfm-icon-block '>                
                                                                                                          <i  class="dashicons dashicons-screenoptions" aria-hidden="true"></i>          
                                            </span>
                                                                                            <span class='name wpfm-menu-name'>
                                                    Lộ trình học                                                </span>
                                                                                                   
                                    </a>
                                                                    </li>
                                                                <li class=" ">
                                    <a title="" class="wpfm-menu-link" href="https://cybersoft.edu.vn/lien-he/"    >
                                                                                    <span class='wpfm-icon-block '>                
                                                                                                          <i  class="fa fa-envelope" aria-hidden="true"></i>          
                                            </span>
                                                                                            <span class='name wpfm-menu-name'>
                                                    Liên hệ tư vấn                                                </span>
                                                                                                   
                                    </a>
                                                                    </li>
                                                                <li class=" ">
                                    <a title="" class="wpfm-menu-link" href="https://www.youtube.com/channel/UCWc3ASTJcb0FeO2oFfX8IDQ" target="_blank" target="_blank"  >
                                                                                    <span class='wpfm-icon-block '>                
                                                                                                          <i  class="fa fa-youtube-play" aria-hidden="true"></i>          
                                            </span>
                                                                                            <span class='name wpfm-menu-name'>
                                                    Kênh Youtube                                                </span>
                                                                                                   
                                    </a>
                                                                    </li>
                                                                <li class=" ">
                                    <a title="" class="wpfm-menu-link" href="https://www.facebook.com/lophocviet/" target="_blank" target="_blank"  >
                                                                                    <span class='wpfm-icon-block '>                
                                                                                                          <i  class="fa fa-facebook" aria-hidden="true"></i>          
                                            </span>
                                                                                            <span class='name wpfm-menu-name'>
                                                    Facebook                                                </span>
                                                                                                   
                                    </a>
                                                                    </li>
                                  
                </ul>             
            </nav>
        </div>
        <style type="text/css">
        /* Font Icon Background*/
        .wpfm-71438.wpfm-template-1 ul li,
        .wpfm-71438.wpfm-template-1 ul li .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-right ul li:hover .wpfm-icon-block, 
        .wpfm-71438.wpfm-template-1 .wpfm-position-top-right ul li:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-bottom-right ul li:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-top-left ul li.wpfm-title-hidden:hover .wpfm-icon-block, 
        .wpfm-71438.wpfm-template-1 .wpfm-position-bottom-left ul li.wpfm-title-hidden:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-left ul li.wpfm-title-hidden:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-top-right ul li.wpfm-title-hidden:hover .wpfm-icon-block ,
        .wpfm-71438.wpfm-template-1 .wpfm-position-bottom-right ul li.wpfm-title-hidden:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-right ul li.wpfm-title-hidden:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-left ul li:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-top-left ul li:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-bottom-left ul li:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav.wpfm-position-left ul li,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav.wpfm-position-top-left ul li,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav.wpfm-position-bottom-left ul li,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav.wpfm-position-right ul li,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav.wpfm-position-top-right ul li,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav.wpfm-position-bottom-right ul li,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-left ul > li > a span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-top-left ul > li > a span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-bottom-left ul > li > a span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-left ul li:hover,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-top-left ul li:hover,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-bottom-left ul li:hover,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-right ul > li > a span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-right ul li:hover,
        .wpfm-71438.wpfm-template-4 ul li .wpfm-icon-block,
        .wpfm-71438.wpfm-template-7 ul > li > a,
        .wpfm-71438.wpfm-template-8 .wpfm-menu-nav a .wpfm-icon-block, 
        .wpfm-71438.wpfm-template-8 .wpfm-menu-nav a::before,
        .wpfm-71438.wpfm-template-9 .wpfm-menu-nav a .wpfm-icon-block, 
        .wpfm-71438.wpfm-template-9 .wpfm-menu-nav a::before,
        .wpfm-71438.wpfm-template-10 ul li a span, 
        .wpfm-71438.wpfm-template-10 ul li:before,
        .wpfm-71438.wpfm-template-12 .wpfm-menu-nav ul li a,
        .wpfm-71438.wpfm-template-13 .wpfm-menu-nav ul li a
        { 
            background: #dbb80d;                    
        }

        /* Menu Title Line for template 7 */
        .wpfm-71438 .wpfm-template-7 span.name.wpfm-menu-name:after
        {
            border-bottom: 2px solid ;
        }
        /* Menu Background for template 5,6,8,9 */
        .wpfm-71438.wpfm-template-5 ul,.wpfm-template-5 .wpfm-nav-strech-trigger span,
        .wpfm-71438.wpfm-template-6 .wpfm-menu-nav ul:before,.wpfm-template-6 .wpfm-nav-strech-trigger span,
        .wpfm-71438.wpfm-template-6 .wpfm-menu-name,
        .wpfm-71438.wpfm-template-7 span.name.wpfm-menu-name:after,
        .wpfm-71438.wpfm-template-8 .wpfm-menu-nav:before,
        .wpfm-71438.wpfm-template-9 .wpfm-menu-nav .wpfm-nav:before,
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav ul, 
        .wpfm-71438.wpfm-template-12 .wpfm-menu-nav ul        
        {
            background: ;
        }

        /* For Title Color, Font Family*/   
        .wpfm-71438.wpfm-template-1 .wpfm-menu-nav.wpfm-position-right ul li > a:hover > span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-1 .wpfm-menu-nav.wpfm-position-top-right ul li > a:hover > span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-1 .wpfm-menu-nav.wpfm-position-bottom-right ul li > a:hover > span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-1 ul li .wpfm-menu-name,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-left ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-right ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-4 ul li .wpfm-menu-name,.wpfm-template-3 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-6 .wpfm-menu-name,
        .wpfm-71438.wpfm-template-7 .wpfm-menu-name,
        .wpfm-71438.wpfm-template-8 .wpfm-menu-nav:hover .wpfm-menu-name,
        .wpfm-71438.wpfm-template-9 .wpfm-menu-nav .wpfm-menu-name,
        .wpfm-71438.wpfm-template-10 .wpfm-menu-nav ul li .wpfm-tooltip span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-12 .wpfm-menu-nav .wpfm-icon-menu-name-wrapper span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-13 .wpfm-menu-nav .wpfm-icon-menu-name-wrapper span.wpfm-menu-name
        { 
            color:;
            font-family:default; 
        }
        /* For Title Font Size, Text Transformation */  
        .wpfm-71438.wpfm-template-1 a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-4 ul li .wpfm-menu-name,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-6 .wpfm-menu-name,
        .wpfm-71438.wpfm-template-7 .wpfm-menu-name,
        .wpfm-71438.wpfm-template-8 .wpfm-menu-nav:hover .wpfm-menu-name,
        .wpfm-71438.wpfm-template-9.wpfm-position-left  .wpfm-nav:hover .wpfm-menu-name,
        .wpfm-71438.wpfm-template-9.wpfm-position-top-left  .wpfm-nav:hover .wpfm-menu-name,
        .wpfm-71438.wpfm-template-9.wpfm-position-bottom-left  .wpfm-nav:hover .wpfm-menu-name,
        .wpfm-71438.wpfm-template-9.wpfm-position-right  .wpfm-nav:hover .wpfm-menu-name,
        .wpfm-71438.wpfm-template-9.wpfm-position-top-right  .wpfm-nav:hover .wpfm-menu-name,
        .wpfm-71438.wpfm-template-9.wpfm-position-bottom-right  .wpfm-nav:hover .wpfm-menu-name,
        .wpfm-71438.wpfm-template-10 .wpfm-menu-nav ul li .wpfm-tooltip span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav ul li a span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-12 .wpfm-menu-nav .wpfm-icon-menu-name-wrapper span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-13 .wpfm-menu-nav .wpfm-icon-menu-name-wrapper span.wpfm-menu-name
        { 
            font-size:12px;
            text-transform:uppercase;
        }
        /* For Icon Size */   
        .wpfm-71438.wpfm-template-1 .wpfm-menu-nav ul li > a .wpfm-icon-block i,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav ul li a span i,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav ul li a span i,
        .wpfm-71438.wpfm-template-4 .wpfm-menu-nav ul li a span i,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li a span.wpfm-icon-block i,
        .wpfm-71438.wpfm-template-6 .wpfm-icon-block i,.wpfm-template-6 .wpfm-nav-close-trigger span,
        .wpfm-71438.wpfm-template-6 .wpfm-nav-strech-trigger span,
        .wpfm-71438.wpfm-template-8 .wpfm-menu-nav a .wpfm-icon-block i,
        .wpfm-71438.wpfm-template-9 .wpfm-menu-nav a .wpfm-icon-block i,
        .wpfm-71438.wpfm-template-10 .wpfm-tooltip .wpfm-icon-block i,
        .wpfm-71438.wpfm-template-11 .wpfm-tooltip .wpfm-icon-block i
        {
            font-size:px;
        }
        .wpfm-71438.wpfm-template-1 .wpfm-menu-nav ul li a img,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav ul li a span img.wpfm-image-icon,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav ul li a span img.wpfm-image-icon,
        .wpfm-71438.wpfm-template-4 .wpfm-menu-nav ul li a span img.wpfm-image-icon,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li a span.wpfm-icon-block img.wpfm-image-icon,
        .wpfm-71438.wpfm-template-6 .wpfm-icon-block img,
        .wpfm-71438.wpfm-template-8 .wpfm-menu-nav a .wpfm-icon-block img,
        .wpfm-71438.wpfm-template-9 .wpfm-menu-nav a .wpfm-icon-block img,
        .wpfm-71438.wpfm-template-10 .wpfm-tooltip .wpfm-icon-block img,
        .wpfm-71438.wpfm-template-11 .wpfm-tooltip .wpfm-icon-block img
        {
            width:50px !important;
        }
        /* For height width of icon hover transform for template 7 */
        .wpfm-71438.wpfm-template-7 ul > li > a:hover,
        .wpfm-71438.wpfm-template-7 ul > li.wpfm-active-nav a
        { 
            background: ;
            -webkit-transform:scale(1) translate3d(0,0,0);
            transform:scale(1) translate3d(0,0,0);
        }

        /* Title Background Color For Template 4,6 and 10 */
        .wpfm-71438.wpfm-template-4 .wpfm-menu-nav ul li >a:hover >span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-10 .wpfm-tooltip,
        .wpfm-71438.wpfm-template-12 .wpfm-menu-nav .wpfm-icon-menu-name-wrapper,
        .wpfm-71438.wpfm-template-7 .wpfm-menu-name,
        .wpfm-71438.wpfm-template-13 .wpfm-menu-nav .wpfm-icon-menu-name-wrapper
        { 
            background:; 
        }
        .wpfm-71438.wpfm-template-7 span.name.wpfm-menu-name:after{    
            border-bottom: 2px solid ;
        }
        /* For Icon margin */  
        .wpfm-71438.wpfm-template-1 ul li, .wpfm-template-2 ul li,
        .wpfm-71438.wpfm-template-3 ul li, .wpfm-template-4 ul li,
        .wpfm-71438.wpfm-template-4 ul li a,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li a,
        .wpfm-71438.wpfm-template-6 ul li a,
        .wpfm-71438.wpfm-template-8 .wpfm-menu-nav a,
        .wpfm-71438.wpfm-template-9 .wpfm-menu-nav a
        {
            margin-bottom:px;
        }
        /** Tooltip Title */
        .wpfm-71438.wpfm-template-1 ul li > .wpfm-tootltip-title, 
        .wpfm-71438.wpfm-template-2 ul li > .wpfm-tootltip-title, 
        .wpfm-71438.wpfm-template-3 ul li > .wpfm-tootltip-title, 
        .wpfm-71438.wpfm-template-4 ul li > .wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-8.wpfm-position-right .wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-8.wpfm-position-top-right .wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-8.wpfm-position-bottom-right .wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li > span.wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-6 .wpfm-menu-nav ul li  span.wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-7 ul li > .wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-8 .wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-9 .wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav ul li .wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-12 .wpfm-menu-nav ul li .wpfm-tootltip-title,
        .wpfm-71438.wpfm-template-13 .wpfm-menu-nav ul li .wpfm-tootltip-title
        {
            color: ;
            background: ;
            font-size: 12px;
            font-family: default;
            text-transform: uppercase;
        }

        .wpfm-template-10 ul li:last-child:before {
            height: 0;
        }
        .wpfm-71438.wpfm-template-7 ul li > .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-8.wpfm-position-left .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-top-left .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-bottom-left .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-right .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-top-right .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-bottom-right .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-left .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-top-left .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-bottom-left .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-right .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-top-right .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-bottom-right .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-9.wpfm-position-left .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-9.wpfm-position-top-left .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-9.wpfm-position-bottom-left .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-9.wpfm-position-right .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-9.wpfm-position-top-right .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-9.wpfm-position-bottom-right .wpfm-tootltip-title:after
        {               
            color: ;
        }
        /* Border color for tooltip text arrow */
        .wpfm-71438.wpfm-template-1 .wpfm-position-right ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-1 .wpfm-position-top-right ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-1 .wpfm-position-bottom-right ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-2 .wpfm-position-right ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-2 .wpfm-position-top-right ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-2 .wpfm-position-bottom-right ul li > .wpfm-tootltip-title:after, 
        .wpfm-71438.wpfm-template-3 .wpfm-position-right ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-3 .wpfm-position-top-right ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-3 .wpfm-position-bottom-right ul li > .wpfm-tootltip-title:after,                
        .wpfm-71438.wpfm-template-4 .wpfm-position-right ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-4 .wpfm-position-top-right ul li > .wpfm-tootltip-title:after,                 
        .wpfm-71438.wpfm-template-4 .wpfm-position-bottom-right ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-5 .wpfm-position-right ul li  span.wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-5 .wpfm-position-top-right ul li  span.wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav.wpfm-position-bottom-right ul li  span.wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-6 .wpfm-position-right ul li  span.wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-6 .wpfm-position-top-right ul li  span.wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-6 .wpfm-position-bottom-right ul li  span.wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-7 .wpfm-position-top-right ul li.wpfm-title-hidden > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-7 .wpfm-position-right ul li.wpfm-title-hidden > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-7 .wpfm-position-bottom-right ul li.wpfm-title-hidden > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-right .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-8.wpfm-position-top-right .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-8.wpfm-position-bottom-right .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-9.wpfm-position-right .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-9.wpfm-position-top-right .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-9.wpfm-position-bottom-right .wpfm-tootltip-title:before,              
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav.wpfm-position-right ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-12 .wpfm-menu-nav.wpfm-position-right ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-13 .wpfm-menu-nav.wpfm-position-right ul li .wpfm-tootltip-title:after
        {
            border-color:transparent transparent transparent ;
        }
        .wpfm-71438.wpfm-template-1 .wpfm-position-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-1 .wpfm-position-top-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-1 .wpfm-position-bottom-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-2 .wpfm-position-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-2 .wpfm-position-top-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-2 .wpfm-position-bottom-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-3 .wpfm-position-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-3 .wpfm-position-top-left ul li > .wpfm-tootltip-title:after, 
        .wpfm-71438.wpfm-template-3 .wpfm-position-bottom-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-3 .wpfm-position-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-3 .wpfm-position-top-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-3 .wpfm-position-bottom-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-4 .wpfm-position-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-4 .wpfm-position-top-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-4 .wpfm-position-bottom-left ul li > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-5 .wpfm-position-left ul li  span.wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-5 .wpfm-position-top-left ul li  span.wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav.wpfm-position-bottom-left ul li  span.wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-6 .wpfm-position-left ul li  span.wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-6 .wpfm-position-top-left ul li  span.wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-6 .wpfm-position-bottom-left ul li  span.wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-7 .wpfm-position-top-left ul li.wpfm-title-hidden > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-7 .wpfm-position-left ul li.wpfm-title-hidden > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-7 .wpfm-position-bottom-left ul li.wpfm-title-hidden > .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-8.wpfm-position-left .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-8.wpfm-position-top-left .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-8.wpfm-position-bottom-left .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-9.wpfm-position-left .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-9.wpfm-position-top-left .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-9.wpfm-position-bottom-left .wpfm-tootltip-title:before,
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav.wpfm-position-left ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-12 .wpfm-menu-nav.wpfm-position-left ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-13 .wpfm-menu-nav.wpfm-position-left ul li .wpfm-tootltip-title:after
        {
            border-color:transparent  transparent transparent;  
        }
        .wpfm-71438.wpfm-template-11 .wpfm-position-bottom-left ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-12 .wpfm-position-bottom-left ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-13 .wpfm-position-bottom-left ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-11 .wpfm-position-bottom-right ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-12 .wpfm-position-bottom-right ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-13 .wpfm-position-bottom-right ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-11 .wpfm-position-bottom-center ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-12 .wpfm-position-bottom-center ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-13 .wpfm-position-bottom-center ul li .wpfm-tootltip-title:after,
        .wpfm-71438.wpfm-template-7 ul li > .wpfm-tootltip-title:after
        {
            border-top: 7px solid ;
        }
        .wpfm-template-11 .wpfm-position-top-left ul li .wpfm-tootltip-title:after, .wpfm-template-12 .wpfm-position-top-left ul li .wpfm-tootltip-title:after, .wpfm-template-13 .wpfm-position-top-left ul li .wpfm-tootltip-title:after, .wpfm-template-11 .wpfm-position-top-right ul li .wpfm-tootltip-title:after, .wpfm-template-12 .wpfm-position-top-right ul li .wpfm-tootltip-title:after, .wpfm-template-13 .wpfm-position-top-right ul li .wpfm-tootltip-title:after
        {
            border-bottom:7px solid ;
        }

        /* active hover color for inline navigation and sticky menu */
        .wpfm-71438.wpfm-template-1 ul li.wpfm-active-nav,
        .wpfm-71438.wpfm-template-1 ul li.wpfm-active-nav .wpfm-icon-block, 
        .wpfm-71438.wpfm-template-1 .wpfm-position-left ul li.wpfm-active-nav:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-top-left ul li.wpfm-active-nav:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-bottom-left ul li.wpfm-active-nav:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-right ul li.wpfm-active-nav:hover .wpfm-icon-block, 
        .wpfm-71438.wpfm-template-1 .wpfm-position-top-right ul li.wpfm-active-nav:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-bottom-right ul li.wpfm-active-nav:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-left ul li.wpfm-title-hidden.wpfm-active-nav:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-top-left ul li.wpfm-title-hidden.wpfm-active-nav:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-1 .wpfm-position-bottom-left ul li.wpfm-title-hidden.wpfm-active-nav:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-2 .wpfm-menu-nav ul li.wpfm-active-nav,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-left ul > li.wpfm-active-nav span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-top-left ul > li.wpfm-active-nav span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-bottom-left ul > li.wpfm-active-nav span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-right ul > li.wpfm-active-nav span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-top-right ul > li.wpfm-active-nav span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-bottom-right ul > li.wpfm-active-nav span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-left ul li.wpfm-active-nav,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-top-left ul li.wpfm-active-nav,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-bottom-left ul li.wpfm-active-nav,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-right ul li.wpfm-active-nav,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-top-right ul li.wpfm-active-nav,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-bottom-right ul li.wpfm-active-nav,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-left ul li.wpfm-active-nav:hover,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-top-left ul li.wpfm-active-nav:hover,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-bottom-left ul li.wpfm-active-nav:hover,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-right ul li.wpfm-active-nav:hover,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-top-right ul li.wpfm-active-nav:hover,
        .wpfm-71438.wpfm-template-3 .wpfm-menu-nav.wpfm-position-bottom-right ul li.wpfm-active-nav:hover,
        .wpfm-71438.wpfm-template-4 .wpfm-position-left ul li a:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-top-left ul li a:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-bottom-left ul li a:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-right ul li a:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-top-right ul li a:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-bottom-right ul li a:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-left ul li.wpfm-active-nav  span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-top-left ul li.wpfm-active-nav span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-bottom-left ul li.wpfm-active-nav  span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-right ul li.wpfm-active-nav  span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-top-right ul li.wpfm-active-nav  span.wpfm-icon-block,
        .wpfm-71438.wpfm-template-4 .wpfm-position-bottom-right ul li.wpfm-active-nav  span.wpfm-icon-block,
        .wpfm-71438 li.wpfm-title-hidden.wpfm-active-nav span.wpfm-image-icon-block,
        .wpfm-71438 li.wpfm-active-nav span.wpfm-image-icon-block,
        .wpfm-71438.wpfm-template-8 .wpfm-menu-nav li.wpfm-active-nav .wpfm-icon-block,
        .wpfm-71438.wpfm-template-9 .wpfm-menu-nav li.wpfm-active-nav .wpfm-icon-block,
        .wpfm-71438.wpfm-template-10 ul li a:hover span,
        .wpfm-71438.wpfm-template-10 ul li.wpfm-active-nav span.wpfm-initia-icon,
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav ul li.wpfm-active-nav span.wpfm-image-icon-block,
        .wpfm-71438.wpfm-template-12 .wpfm-menu-nav ul li.wpfm-active-nav a,
        .wpfm-71438.wpfm-template-13 .wpfm-menu-nav ul li.wpfm-active-nav a
        {
            background:;
        }

        /* Active class implementation in template 5 and 6 and 11*/
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li a:hover span.wpfm-icon-block i,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li a:hover span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li.wpfm-active-nav span.wpfm-icon-block i,
        .wpfm-71438.wpfm-template-5 .wpfm-menu-nav ul li.wpfm-active-nav span.wpfm-menu-name,
        .wpfm-71438.wpfm-template-6 ul li.wpfm-active-nav .wpfm-icon-block,
        .wpfm-71438.wpfm-template-6 ul li a:hover .wpfm-icon-block,
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav ul li a:hover span,
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav ul li.wpfm-active-nav span,
        .wpfm-71438.wpfm-template-11 .wpfm-menu-nav ul li.wpfm-active-nav span.wpfm-icon-menu-name-wrapper i
        {
            color: !important;
        }

        .wpfm-71438 img.wpfm-trigger-image-icon{
            padding:10px;
        }

        .wpfm-71438.wpfm-template-5 .wpfm-nav-strech-trigger span i{
            color:        }

        .wpfm-71438.wpfm-template-5 .wpfm-nav-close-trigger span i{
            color:        }

        /* 
        *.wpfm-template-12 .wpfm-menu-nav .wpfm-icon-menu-name-wrapper, .wpfm-template-13 .wpfm-menu-nav .wpfm-icon-menu-name-wrapper
        */
    </style>
                        <style type="text/css">
                    /* Portrait and Landscape */
                    @media only screen 
                    and (min-device-width: 320px) 
                    and (max-device-width: 480px)
                    and (-webkit-min-device-pixel-ratio: 2) {
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* Portrait */
                    @media only screen 
                    and (min-device-width: 320px) 
                    and (max-device-width: 480px)
                    and (-webkit-min-device-pixel-ratio: 2)
                    and (orientation: portrait) {
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* Landscape */
                    @media only screen 
                    and (min-device-width: 320px) 
                    and (max-device-width: 480px)
                    and (-webkit-min-device-pixel-ratio: 2)
                    and (orientation: landscape) {
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* ----------- iPhone 5 and 5S ----------- */

                    /* Portrait and Landscape */
                    @media only screen 
                    and (min-device-width: 320px) 
                    and (max-device-width: 568px)
                    and (-webkit-min-device-pixel-ratio: 2) {
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* Portrait */
                    @media only screen 
                    and (min-device-width: 320px) 
                    and (max-device-width: 568px)
                    and (-webkit-min-device-pixel-ratio: 2)
                    and (orientation: portrait) {
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* Landscape */
                    @media only screen 
                    and (min-device-width: 320px) 
                    and (max-device-width: 568px)
                    and (-webkit-min-device-pixel-ratio: 2)
                    and (orientation: landscape) {
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* ----------- iPhone 6 ----------- */

                    /* Portrait and Landscape */
                    @media only screen 
                    and (min-device-width: 375px) 
                    and (max-device-width: 667px) 
                    and (-webkit-min-device-pixel-ratio: 2) { 
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* Portrait */
                    @media only screen 
                    and (min-device-width: 375px) 
                    and (max-device-width: 667px) 
                    and (-webkit-min-device-pixel-ratio: 2)
                    and (orientation: portrait) { 
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* Landscape */
                    @media only screen 
                    and (min-device-width: 375px) 
                    and (max-device-width: 667px) 
                    and (-webkit-min-device-pixel-ratio: 2)
                    and (orientation: landscape) { 
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* ----------- iPhone 6+ ----------- */

                    /* Portrait and Landscape */
                    @media only screen 
                    and (min-device-width: 414px) 
                    and (max-device-width: 736px) 
                    and (-webkit-min-device-pixel-ratio: 3) { 
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* Portrait */
                    @media only screen 
                    and (min-device-width: 414px) 
                    and (max-device-width: 736px) 
                    and (-webkit-min-device-pixel-ratio: 3)
                    and (orientation: portrait) { 
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }

                    /* Landscape */
                    @media only screen 
                    and (min-device-width: 414px) 
                    and (max-device-width: 736px) 
                    and (-webkit-min-device-pixel-ratio: 3)
                    and (orientation: landscape) { 
                        .wpfm-floating-wh-wrapper{display:none; }	
                    }
                </style>
                    </div>
        		<div class="hotline-phone-ring-wrap">
			<div class="hotline-phone-ring">
				<div class="hotline-phone-ring-circle"></div>
				<div class="hotline-phone-ring-circle-fill"></div>
				<div class="hotline-phone-ring-img-circle">
					<a href="tel:0961051014" class="pps-btn-img">
												<img src="https://cybersoft.edu.vn/wp-content/plugins/hotline-phone-ring/assets/images/icon-1.png" alt="Số điện thoại" width="50" />
					</a>
				</div>
			</div>
					</div>
	<div class="wppopups-whole" style="display: none"><div class="spu-bg " id="spu-bg-14748"></div><div class="spu-box spu-animation-fade cyberpopup_style2 spu-position-centered" id="spu-14748" data-id="14748" data-parent="0" data-settings="{&quot;position&quot;:{&quot;position&quot;:&quot;centered&quot;},&quot;animation&quot;:{&quot;animation&quot;:&quot;fade&quot;},&quot;colors&quot;:{&quot;show_overlay&quot;:&quot;yes-color&quot;,&quot;overlay_color&quot;:&quot;rgba(0,0,0,0.5)&quot;,&quot;overlay_blur&quot;:&quot;2&quot;,&quot;bg_color&quot;:&quot;rgb(255, 255, 255)&quot;,&quot;bg_img&quot;:&quot;&quot;,&quot;bg_img_repeat&quot;:&quot;no-repeat&quot;,&quot;bg_img_size&quot;:&quot;auto&quot;},&quot;close&quot;:{&quot;close_color&quot;:&quot;#666&quot;,&quot;close_hover_color&quot;:&quot;#000&quot;,&quot;close_shadow_color&quot;:&quot;#000&quot;,&quot;close_size&quot;:&quot;30&quot;,&quot;close_position&quot;:&quot;top_right&quot;},&quot;popup_box&quot;:{&quot;width&quot;:&quot;460px&quot;,&quot;padding&quot;:&quot;0&quot;,&quot;radius&quot;:&quot;20&quot;,&quot;auto_height&quot;:&quot;yes&quot;,&quot;height&quot;:&quot;350px&quot;},&quot;border&quot;:{&quot;border_type&quot;:&quot;none&quot;,&quot;border_color&quot;:&quot;#000&quot;,&quot;border_width&quot;:&quot;3&quot;,&quot;border_radius&quot;:&quot;0&quot;,&quot;border_margin&quot;:&quot;0&quot;},&quot;shadow&quot;:{&quot;shadow_color&quot;:&quot;#ccc&quot;,&quot;shadow_type&quot;:&quot;outset&quot;,&quot;shadow_x_offset&quot;:&quot;0&quot;,&quot;shadow_y_offset&quot;:&quot;0&quot;,&quot;shadow_blur&quot;:&quot;0&quot;,&quot;shadow_spread&quot;:&quot;0&quot;},&quot;css&quot;:{&quot;custom_css&quot;:&quot;&quot;},&quot;id&quot;:&quot;14748&quot;,&quot;field_id&quot;:1,&quot;rules&quot;:{&quot;group_0&quot;:{&quot;rule_0&quot;:{&quot;rule&quot;:&quot;page_type&quot;,&quot;operator&quot;:&quot;==&quot;,&quot;value&quot;:&quot;all_pages&quot;}}},&quot;global_rules&quot;:{&quot;group_0&quot;:{&quot;rule_0&quot;:{&quot;rule&quot;:&quot;page_type&quot;,&quot;operator&quot;:&quot;==&quot;,&quot;value&quot;:&quot;all_pages&quot;}}},&quot;settings&quot;:{&quot;popup_title&quot;:&quot;uudaihe&quot;,&quot;popup_desc&quot;:&quot;&quot;,&quot;test_mode&quot;:&quot;0&quot;,&quot;powered_link&quot;:&quot;0&quot;,&quot;popup_class&quot;:&quot;cyberpopup_style2&quot;,&quot;popup_hidden_class&quot;:&quot;&quot;,&quot;close_on_conversion&quot;:&quot;1&quot;,&quot;conversion_cookie_name&quot;:&quot;spu_conversion_14472&quot;,&quot;conversion_cookie_duration&quot;:&quot;0&quot;,&quot;conversion_cookie_type&quot;:&quot;d&quot;,&quot;closing_cookie_name&quot;:&quot;spu_closing_14472&quot;,&quot;closing_cookie_duration&quot;:&quot;0&quot;,&quot;closing_cookie_type&quot;:&quot;d&quot;},&quot;triggers&quot;:{&quot;trigger_0&quot;:{&quot;trigger&quot;:&quot;seconds&quot;,&quot;value&quot;:&quot;3&quot;}}}" data-need_ajax="0"><div class="spu-container "><div class="spu-content"><div class="cyberpopup_style1">
<img class="size-large wp-image-5359 aligncenter" src="https://cybersoft.edu.vn/wp-content/uploads/2024/05/uu_dai_he.jpg" alt="" width="1024" height="1024" /></p>
<div class="cyber-try customRegister"><div id="dhvcform-14475"  class="dhvc-form-container dhvc-form-icon-pos-right dhvc-form-vertical dhvc-form-flat">
<div class="dhvc-form-message dhvc-form-message-top" style="display:none"></div>
<form novalidate data-currency="USD" data-currency_symbol="&#036;" data-price_format="%s%v"   data-scroll_to_msg="1" data-ajax_reset_submit="1" data-popup="0" autocomplete="off" data-use-ajax="1" method="post" class="dhvcform dhvcform-14475 dhvcform-action-default" enctype="multipart/form-data" target="_self" >
<div class="dhvc-form-inner">
<div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="dhvc-form-group dhvc-form-hoten3-box dhvc_form_text ">
<div class="dhvc-form-input  dhvc-form-has-add-on">
<input data-field-name="hoten3" autocomplete="off" type="text" id="dhvc_form_control_hoten3" name="hoten3" value=""   class="dhvc-form-control dhvc-form-control-hoten3 dhvc-form-value dhvc-form-required-entry "  required aria-required="true"  placeholder="Họ và tên *" >
<span class="dhvc-form-add-on"><i class="fa fa-user"></i></span>
</div></div>
<div class="dhvc-form-group dhvc-form-sodienthoai3-box dhvc_form_text ">
<div class="dhvc-form-input  dhvc-form-has-add-on">
<input data-field-name="sodienthoai3" autocomplete="off" type="text" id="dhvc_form_control_sodienthoai3" name="sodienthoai3" value=""   class="dhvc-form-control dhvc-form-control-sodienthoai3 dhvc-form-value dhvc-form-required-entry "  required aria-required="true"  placeholder="Điện thoại liên hệ *" >
<span class="dhvc-form-add-on"><i class="fa fa-phone"></i></span>
</div></div>
<div class="dhvc-form-group dhvc-form-email3-box dhvc_form_email ">
<div class="dhvc-form-input  dhvc-form-has-add-on">
<input data-field-name="email3" autocomplete="off" type="email" id="dhvc_form_control_email3" name="email3" value=""  class="dhvc-form-control dhvc-form-control-email3 dhvc-form-value dhvc-form-required-entry dhvc-form-validate-email  "  required aria-required="true"  placeholder="Email liên hệ *" >
<span class="dhvc-form-add-on"><i class="fa fa-envelope"></i></span>
</div></div>
<input type="hidden" id="g-recaptcha-response_capcha3" name="g-recaptcha-response" class="dhvc-form-recaptcha" data-name="capcha3" value="">
<div class="dhvc-form-action dhvc_form_submit_button ">
	<button type="submit" class="button dhvc-form-submit">
		<span class="dhvc-form-submit-label">ĐĂNG KÍ ƯU ĐÃI</span>
		<span class="dhvc-form-submit-spinner">
			<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="25 25 50 50"  xml:space="preserve">
				<circle class="path" cx="50" cy="50" r="20" stroke-dasharray="89, 200" stroke="currentColor" stroke-dashoffset="-35" fill="none" stroke-width="5" stroke-miterlimit="10"/>
			</svg>
		</span>
	</button>
</div></div></div></div></div></div><div style="display: none;">
<input type="hidden" name="action" value="dhvc_form_ajax">
<input type="hidden" id="_dhvc_form_hidden_fields" name="_dhvc_form_hidden_fields" value="">
<input type="hidden" name="_dhvc_form_id" value="14475">
<input type="hidden" name="_dhvc_form_url" value="https://cybersoft.edu.vn/signals/iwl.js">
<input type="hidden" name="_dhvc_form_referer" value="http://connect.facebook.net/en_US/fbevents.js">
<input type="hidden" name="_dhvc_form_post_id" value="">
<input type="hidden" name="_dhvc_form_nonce" value="0ef5c38a19">
</div>
</form>
</div>
</div>
</div>
</div><a href="#" class="spu-close spu-close-popup spu-close-top_right">&times;</a><span class="spu-timer"></span></div></div><!--spu-box--></div><noscript><img height="1" width="1" style="display: none;" src="https://www.facebook.com/tr?id=498491967837119&ev=PageView&noscript=1&cd%5Bpost_type%5D&cd%5Bplugin%5D=PixelYourSite&cd%5Buser_role%5D=guest&cd%5Bevent_url%5D=cybersoft.edu.vn%2Fsignals%2Fiwl.js" alt=""></noscript>
<link rel='stylesheet' id='thickbox-css'  href='https://cybersoft.edu.vn/wp-includes/js/thickbox/thickbox.css' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='https://cybersoft.edu.vn/wp-content/plugins/js_composer/assets/css/js_composer.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='modal-window-css'  href='https://cybersoft.edu.vn/wp-content/plugins/modal-window/public/assets/css/style.min.css' type='text/css' media='all' />
<style id='modal-window-inline-css' type='text/css'>
@media only screen and (max-width: 480px){ #wow-modal-window-1 { width:85% !important; } } #wow-modal-close-1 { top: 0px;right: 0px; } #wow-modal-close-1.mw-close-btn.text:before { content: "Close"; color: #fff; padding: 6px 12px; font-family: inherit; font-size: 12px; font-weight: normal; font-style: normal; background: linear-gradient(to right, #fff 50%, #000 50%); background-size: 200% 100%; background-position: right bottom; border-radius: 0; } #wow-modal-close-1.mw-close-btn.text:hover:before { color: #000; background-position: left bottom; }
@media only screen and (max-width: 480px){ #wow-modal-window-2 { width:85% !important; } } #wow-modal-close-2 { top: 0px;right: 0px; } #wow-modal-close-2.mw-close-btn.text:before { content: "Close"; color: #fff; padding: 6px 12px; font-family: inherit; font-size: 12px; font-weight: normal; font-style: normal; background: linear-gradient(to right, #fff 50%, #000 50%); background-size: 200% 100%; background-position: right bottom; border-radius: 0; } #wow-modal-close-2.mw-close-btn.text:hover:before { color: #000; background-position: left bottom; }
</style>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-includes/js/dist/vendor/wp-polyfill.min.js'></script>
<script type='text/javascript'>
( 'fetch' in window ) || document.write( '<script src="https://cybersoft.edu.vn/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js"></scr' + 'ipt>' );( document.contains ) || document.write( '<script src="https://cybersoft.edu.vn/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js"></scr' + 'ipt>' );( window.FormData && window.FormData.prototype.keys ) || document.write( '<script src="https://cybersoft.edu.vn/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js"></scr' + 'ipt>' );( Element.prototype.matches && Element.prototype.closest ) || document.write( '<script src="https://cybersoft.edu.vn/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js"></scr' + 'ipt>' );
</script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-includes/js/dist/hooks.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wppopups_vars = {"is_admin":"","ajax_url":"https:\/\/cybersoft.edu.vn\/wp-admin\/admin-ajax.php","pid":"0","is_front_page":"","is_blog_page":"","is_category":"","site_url":"https:\/\/cybersoft.edu.vn","is_archive":"","is_search":"","is_singular":"","is_preview":"","facebook":"","twitter":"","val_required":"This field is required.","val_url":"Please enter a valid URL.","val_email":"Please enter a valid email address.","val_number":"Please enter a valid number.","val_checklimit":"You have exceeded the number of allowed selections: {#}.","val_limit_characters":"{count} of {limit} max characters.","val_limit_words":"{count} of {limit} max words."};
/* ]]> */
</script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/wp-popups-lite/src/assets/js/wppopups.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var sticky_anything_engage = {"element":".menufrontend,.menugioithieu,.cyberLeftMenu,.cyberLeftIntro,.cyberLeftBlog,.cyberThankYou,.cyberLeftBusiness","topspace":"100","minscreenwidth":"0","maxscreenwidth":"999999","zindex":"1","legacymode":"","dynamicmode":"","debugmode":"","pushup":".cyber_stats_section","adminbar":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/sticky-menu-or-anything-on-scroll/assets/js/stickThis.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/wp-sticky-anything/assets/js/wpsticky.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var hgMailchimpConfig = {"ajaxurl":"\/wp-admin\/admin-ajax.php","l10n":{"error":"Error:"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/themes/kallyas/framework/hogash-mailchimp/assets/js/hg-mailchimp.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/themes/kallyas/js/plugins.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/themes/kallyas/addons/scrollmagic/scrollmagic.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var zn_do_login = {"ajaxurl":"\/wp-admin\/admin-ajax.php","add_to_cart_text":"Item Added to cart!"};
var ZnThemeAjax = {"ajaxurl":"\/wp-admin\/admin-ajax.php","zn_back_text":"Back","zn_color_theme":"light","res_menu_trigger":"992","top_offset_tolerance":"","logout_url":"https:\/\/cybersoft.edu.vn\/wp-login.php?action=logout&redirect_to=https%3A%2F%2Fcybersoft.edu.vn&_wpnonce=5c2ee1ccfe"};
/* ]]> */
</script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/themes/kallyas/js/znscript.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/animated-text-element//assets/js/typed.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/animated-text-element//assets/js/script.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/themes/kallyas/addons/slick/slick.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/themes/kallyas/framework/zion-builder/dist/znpb_frontend.bundle.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/kallyas-addon-nav-overlay/assets/app.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-includes/js/wp-embed.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var thickboxL10n = {"next":"Trang sau >","prev":"< Trang tr\u01b0\u1edbc","image":"\u1ea2nh","of":"c\u1ee7a","close":"\u0110\u00f3ng","noiframes":"T\u00ednh n\u0103ng n\u00e0y y\u00eau c\u1ea7u b\u1eadt frame. B\u1ea1n c\u00f3 th\u1ec3 \u0111\u00e3 t\u1eaft t\u00ednh n\u0103ng n\u00e0y ho\u1eb7c tr\u00ecnh duy\u1ec7t kh\u00f4ng h\u1ed7 tr\u1ee3.","loadingAnimation":"https:\/\/cybersoft.edu.vn\/wp-includes\/js\/thickbox\/loadingAnimation.gif"};
/* ]]> */
</script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-includes/js/thickbox/thickbox.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/dhvc-form/assets/js/jquery_cookie.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var dhvcformL10n = {"ajax_url":"\/wp-admin\/admin-ajax.php","ajax_submit_url":"\/?dhvc-form-ajax=submit","plugin_url":"https:\/\/cybersoft.edu.vn\/wp-content\/plugins\/dhvc-form","recaptcha_public_key":"6LeIqm8lAAAAAKiIhzHXxhobyeCocIhdyjsvNTZt","_ajax_nonce":"6f89e5e555","date_format":"Y\/m\/d","time_format":"H:i","time_picker_step":"60","dayofweekstart":"1","datetimepicker_lang":"vi","container_class":".vc_row-fluid"};
/* ]]> */
</script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/dhvc-form/assets/js/script.min.js'></script>
<script type='text/javascript' src='https://www.google.com/recaptcha/api.js?onload=dhvc_form_recatptcha_callback&#038;render=explicit&#038;hl=en&#038;ver=1.0.0'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/modal-window/public/assets/js/jquery.effects.min.js'></script>
<script type='text/javascript' src='https://cybersoft.edu.vn/wp-content/plugins/modal-window/public/assets/js/jquery.modalWindow.min.js'></script>
<script type='text/javascript'>
jQuery(function() {jQuery("#wow-modal-overlay-1").ModalWindow({"animation":["no","400","no","400"],"overlay":true,"overlay_css":["#00000033"],"action":["click","0"],"closeBtn":[false,"0"],"closeAction":[true,true],"triggers":["wow-modal-id-1","wow-modal-close-1","wow-button-close-1"],"modal_css":{"width":"50%","height":"75%","top":"0%","bottom":"0%","left":"0%","right":"0%","padding":"10px","border-width":0,"border-style":"none","border-color":"#ffffff","position":"fixed","border-radius":"5px","background-color":"#ffffff","box-shadow":"none"},"content_css":{"font-family":"inherit","font-size":"16px"}}); });
jQuery(function() {jQuery("#wow-modal-overlay-2").ModalWindow({"animation":["no","400","no","400"],"overlay":true,"overlay_css":["#00000033"],"action":["click","0"],"closeBtn":[false,"0"],"closeAction":[true,true],"triggers":["wow-modal-id-2","wow-modal-close-2","wow-button-close-2"],"modal_css":{"width":"50%","height":"75%","top":"0%","bottom":"0%","left":"0%","right":"0%","padding":"10px","border-width":0,"border-style":"none","border-color":"#ffffff","position":"fixed","border-radius":"5px","background-color":"#ffffff","box-shadow":"none"},"content_css":{"font-family":"inherit","font-size":"16px"}}); });
</script>
<script type='text/javascript' src='https://www.google.com/recaptcha/api.js?render=6LeIqm8lAAAAAKiIhzHXxhobyeCocIhdyjsvNTZt&#038;ver=5.0.21'></script>

<script type="text/javascript">


			var dhvc_form_recatptcha_widgets = [];
			var dhvc_form_recatptcha_callback = function () {
			    jQuery('.dhvc-form-recaptcha2').each(function(){
					var widget_id = grecaptcha.render( jQuery(this).attr('id'), {
				        'sitekey': '6LeIqm8lAAAAAKiIhzHXxhobyeCocIhdyjsvNTZt',
				        'theme': 'light'
			   		 } );
					dhvc_form_recatptcha_widgets.push(widget_id);
				});
			};
			jQuery(document.body).on('dhvc_form_submit', function(event, form, data) {
				switch ( data.status ) {
					case 'validation_failed':
					case 'spam':
					case 'success':
					case 'upload_failed':
					case 'form_not_exist':
					case 'action_failed':
					case 'call_action_failed':
						for ( var i = 0; i < dhvc_form_recatptcha_widgets.length; i++ ) {
							grecaptcha.reset( dhvc_form_recatptcha_widgets[ i ] );
						}
				}
			});
			


		var dhvc_form_recaptcha3_execute = function(){
			grecaptcha.execute('6LeIqm8lAAAAAKiIhzHXxhobyeCocIhdyjsvNTZt', {action: 'homepage'}).then(function(token) {
                var field = document.getElementById('g-recaptcha-response_capcha3');
				field.setAttribute( 'value', token );
            });
		}

		grecaptcha.ready(function() {
            dhvc_form_recaptcha3_execute();
        });

		jQuery(document.body).on('dhvc_form_submit', function(event, form, data) {
			switch ( data.status ) {
				case 'validation_failed':
				case 'spam':
				case 'success':
				case 'upload_failed':
				case 'form_not_exist':
				case 'action_failed':
				case 'call_action_failed':
					dhvc_form_recaptcha3_execute();
			}
		});
	

</script>
<!-- Zn Framework inline JavaScript--><script type="text/javascript">jQuery(document).ready(function($) {
 $(window).on("load",function(){
            $("#menu-frontendnav li a").mPageScroll2id();
             $("#menu-gioi-thieu li a").mPageScroll2id();
             $("#menu-thankyou li a").mPageScroll2id();
             $("#menu-leftbusiness li a").mPageScroll2id();
        });
});</script>
<script type="text/javascript">


			var dhvc_form_recatptcha_widgets = [];
			var dhvc_form_recatptcha_callback = function () {
			    jQuery('.dhvc-form-recaptcha2').each(function(){
					var widget_id = grecaptcha.render( jQuery(this).attr('id'), {
				        'sitekey': '6LeIqm8lAAAAAKiIhzHXxhobyeCocIhdyjsvNTZt',
				        'theme': 'light'
			   		 } );
					dhvc_form_recatptcha_widgets.push(widget_id);
				});
			};
			jQuery(document.body).on('dhvc_form_submit', function(event, form, data) {
				switch ( data.status ) {
					case 'validation_failed':
					case 'spam':
					case 'success':
					case 'upload_failed':
					case 'form_not_exist':
					case 'action_failed':
					case 'call_action_failed':
						for ( var i = 0; i < dhvc_form_recatptcha_widgets.length; i++ ) {
							grecaptcha.reset( dhvc_form_recatptcha_widgets[ i ] );
						}
				}
			});
			


		var dhvc_form_recaptcha3_execute = function(){
			grecaptcha.execute('6LeIqm8lAAAAAKiIhzHXxhobyeCocIhdyjsvNTZt', {action: 'homepage'}).then(function(token) {
                var field = document.getElementById('g-recaptcha-response_capcha3');
				field.setAttribute( 'value', token );
            });
		}

		grecaptcha.ready(function() {
            dhvc_form_recaptcha3_execute();
        });

		jQuery(document.body).on('dhvc_form_submit', function(event, form, data) {
			switch ( data.status ) {
				case 'validation_failed':
				case 'spam':
				case 'success':
				case 'upload_failed':
				case 'form_not_exist':
				case 'action_failed':
				case 'call_action_failed':
					dhvc_form_recaptcha3_execute();
			}
		});
	

</script>
<svg style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
 <defs>

  <symbol id="icon-znb_close-thin" viewBox="0 0 100 100">
   <path d="m87.801 12.801c-1-1-2.6016-1-3.5 0l-33.801 33.699-34.699-34.801c-1-1-2.6016-1-3.5 0-1 1-1 2.6016 0 3.5l34.699 34.801-34.801 34.801c-1 1-1 2.6016 0 3.5 0.5 0.5 1.1016 0.69922 1.8008 0.69922s1.3008-0.19922 1.8008-0.69922l34.801-34.801 33.699 33.699c0.5 0.5 1.1016 0.69922 1.8008 0.69922 0.69922 0 1.3008-0.19922 1.8008-0.69922 1-1 1-2.6016 0-3.5l-33.801-33.699 33.699-33.699c0.89844-1 0.89844-2.6016 0-3.5z"/>
  </symbol>


  <symbol id="icon-znb_play" viewBox="0 0 22 28">
   <path d="M21.625 14.484l-20.75 11.531c-0.484 0.266-0.875 0.031-0.875-0.516v-23c0-0.547 0.391-0.781 0.875-0.516l20.75 11.531c0.484 0.266 0.484 0.703 0 0.969z"></path>
  </symbol>

 </defs>
</svg>
</body>
</html>
</div>